<?php
/**
 * Plugin Name: LatePoint Addon - Coupons
 * Plugin URI:  https://latepoint.com/
 * Description: LatePoint addon for coupons
 * Version:     1.0.7
 * Author:      LatePoint
 * Author URI:  https://latepoint.com/
 * Text Domain: latepoint-coupons
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}

// If no LatePoint class exists - exit, because LatePoint plugin is required for this addon

if ( ! class_exists( 'LatePointAddonCoupons' ) ) :

/**
 * Main Addon Class.
 *
 */

class LatePointAddonCoupons {

  /**
   * Addon version.
   *
   */
  public $version = '1.0.7';
  public $db_version = '1.0.0';
  public $addon_name = 'latepoint-coupons';




  /**
   * LatePoint Constructor.
   */
  public function __construct() {
    $this->define_constants();
    $this->init_hooks();
  }

  /**
   * Define LatePoint Constants.
   */
  public function define_constants() {
    $upload_dir = wp_upload_dir();

    global $wpdb;
    $this->define( 'LATEPOINT_TABLE_COUPONS', $wpdb->prefix . 'latepoint_coupons');

    $this->define( 'LATEPOINT_COUPON_STATUS_ACTIVE', 'active' );
    $this->define( 'LATEPOINT_COUPON_STATUS_DISABLED', 'disabled' );
  }


  public static function public_stylesheets() {
    return plugin_dir_url( __FILE__ ) . 'public/stylesheets/';
  }

  /**
   * Define constant if not already set.
   *
   */
  public function define( $name, $value ) {
    if ( ! defined( $name ) ) {
      define( $name, $value );
    }
  }

  /**
   * Include required core files used in admin and on the frontend.
   */
  public function includes() {

    // CONTROLLERS
    include_once(dirname( __FILE__ ) . '/lib/controllers/coupons_controller.php' );

    // HELPERS
    include_once(dirname( __FILE__ ) . '/lib/helpers/coupon_helper.php' );

    // MODELS
    include_once(dirname( __FILE__ ) . '/lib/models/coupon_model.php' );

  }

  public function add_menu_links($menus){
    if(!OsAuthHelper::is_admin_logged_in()) return $menus;
    array_splice($menus, 8, 0, [['id' => 'customers', 'label' => __( 'Coupons', 'latepoint-coupons' ), 'icon' => 'latepoint-icon latepoint-icon-tag', 'link' => OsRouterHelper::build_link(['coupons', 'index'])]]);
    return $menus;
  }

  public function init_hooks(){
    add_action('latepoint_init', [$this, 'latepoint_init']);
    add_action('latepoint_includes', [$this, 'includes']);

    add_action( 'init', array( $this, 'init' ), 0 );

    add_filter('latepoint_installed_addons', [$this, 'register_addon']);
    add_filter('latepoint_side_menu', [$this, 'add_menu_links']);
    add_filter('latepoint_addons_sqls', [$this, 'db_sqls']);
    add_filter('latepoint_other_reasons_to_show_payment_step', [$this, 'add_reason_to_show_payment_step']);

    add_filter('latepoint_filter_payment_total_info', 'OsCouponHelper::get_payment_total_info_with_coupon_html', 10, 2);

    add_filter('latepoint_full_amount', 'OsCouponHelper::apply_coupons_on_amount', 15, 3 );
    add_filter('latepoint_need_to_show_payment_step', [$this, 'need_to_show_payment_step']);
    add_filter('latepoint_step_show_next_btn_rules', [$this, 'add_step_show_next_btn_rules'], 10, 2);


    add_filter('latepoint_bookings_data_for_csv_export', [$this, 'add_coupon_code_to_bookings_data_for_csv'], 11, 2);
    add_filter('latepoint_booking_row_for_csv_export', [$this, 'add_coupon_code_to_booking_row_for_csv'], 11, 3);

    add_filter('latepoint_bookings_table_columns', [$this, 'add_coupon_columns_to_bookings_table']);
    add_filter('latepoint_before_booking_save_frontend', [$this, 'set_coupon_discount']);

    add_action('latepoint_step_confirmation_payment_info', [$this, 'show_coupon_info_on_confirmation']);
    add_action('latepoint_step_verify_payment_info', [$this, 'show_coupon_info_on_confirmation']);
    add_action('latepoint_booking_quick_form_payment_info_after', [$this, 'show_coupon_info_on_booking_quick_edit_form']);


    // Change the update message to have a proper link to update
    add_action( 'in_plugin_update_message-latepoint-coupons/latepoint-coupons.php', 'OsUpdatesHelper::modify_addon_update_message', 10, 2 );

    register_activation_hook(__FILE__, [$this, 'on_activate']);
    register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);


  }



  /**
   * Init LatePoint when WordPress Initialises.
   */
  public function init() {
    // Set up localisation.
    $this->load_plugin_textdomain();
  }

  public function latepoint_init(){
    LatePoint\Cerber\Router::init_addon();
  }

  public function load_plugin_textdomain() {
    load_plugin_textdomain('latepoint-coupons', false, dirname(plugin_basename(__FILE__)) . '/languages');
  }

  public function on_deactivate(){
  }

  public function on_activate(){
    if(class_exists('OsDatabaseHelper')) OsDatabaseHelper::check_db_version_for_addons();
    do_action('latepoint_on_addon_activate', $this->addon_name, $this->version);
  }

  public function register_addon($installed_addons){
    $installed_addons[] = ['name' => $this->addon_name, 'db_version' => $this->db_version, 'version' => $this->version];
    return $installed_addons;
  }

  public function set_coupon_discount($booking){
    $booking->coupon_discount = $booking->full_amount_to_charge(false) - $booking->full_amount_to_charge();
    return $booking;
  }

  public function add_step_show_next_btn_rules($rules, $step_name){
    // if not accepting payments - the payment step can be skipped because it only shows coupon code input
    if(!OsPaymentsHelper::is_accepting_payments()) $rules['payment'] = true;
    return $rules;
  }

  public function show_coupon_info_on_booking_quick_edit_form($booking){
    ?>
      <div class="os-row">
        <div class="os-col-lg-6">
          <?php echo OsFormHelper::text_field('booking[coupon_code]', __('Coupon Code', 'latepoint'), $booking->coupon_code); ?>
        </div>
        <div class="os-col-lg-6">
          <?php echo OsFormHelper::text_field('booking[coupon_discount]', __('Coupon Discount', 'latepoint'), OsMoneyHelper::format_price($booking->coupon_discount)); ?>
        </div>
      </div>
    <?php
  }

  public function add_reason_to_show_payment_step($has_reasons){
    // show payment step so user can enter coupon code
    return true;
  }

  public function db_sqls($sqls){

    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    $sqls[] = "CREATE TABLE ".LATEPOINT_TABLE_COUPONS." (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      code varchar(110) NOT NULL,
      name varchar(110),
      discount_type varchar(110),
      discount_value decimal(10,2),
      description text,
      rules text,
      status varchar(20) NOT NULL,
      created_at datetime,
      updated_at datetime,
      UNIQUE KEY code_index (code),
      PRIMARY KEY  (id)
    ) $charset_collate;";
    return $sqls;
  }

  public function need_to_show_payment_step($need){
    $need = true;
    return $need;
  }

  public function show_coupon_info_on_confirmation($booking){
    if($booking->coupon_code) echo '<li>'.__('Coupon Code:', 'latepoint-coupons').' <strong>'.$booking->coupon_code.'</strong></li>';
  }


  public function add_coupon_code_to_booking_row_for_csv($booking_row, $booking, $params = []){
    $booking_row[] = $booking->coupon_code;
    $booking_row[] = $booking->coupon_discount;
    return $booking_row;
  }


  public function add_coupon_code_to_bookings_data_for_csv($bookings_data, $params = []){
    $bookings_data[0][] = __('Coupon Code', 'latepoint-coupons');
    $bookings_data[0][] = __('Coupon Discount', 'latepoint-coupons');
    return $bookings_data;
  }



  public function add_coupon_columns_to_bookings_table($columns){
    $columns['booking']['coupon_code'] = __('Coupon Code', 'latepoint');
    $columns['booking']['coupon_discount'] = __('Coupon Discount', 'latepoint');
    return $columns;
  }



}

endif;
if ( in_array( 'latepoint/latepoint.php', get_option( 'active_plugins', array() ) )  || array_key_exists('latepoint/latepoint.php', get_site_option('active_sitewide_plugins', array())) ) {
	$LATEPOINT_ADDON_COUPONS = new LatePointAddonCoupons();
}
$latepoint_session_salt = 'ZjYwNTU0MzgtNDAwNC00OTgzLTgzMTUtNWZmNDlkNmUwNjUy';
