<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}


if ( ! class_exists( 'OsCouponsController' ) ) :


  class OsCouponsController extends OsController {

    function __construct(){
      parent::__construct();
      
      $this->action_access['public'] = array_merge($this->action_access['public'], ['apply']);
      $this->views_folder = plugin_dir_path( __FILE__ ) . '../views/coupons/';
      $this->vars['page_header'] = __('Coupons', 'latepoint-coupons');
      $this->vars['breadcrumbs'][] = array('label' => __('Coupons', 'latepoint-coupons'), 'link' => OsRouterHelper::build_link(OsRouterHelper::build_route_name('coupons', 'index') ) );
    }


    public function index(){
      
      $this->vars['breadcrumbs'][] = array('label' => __('All Coupons', 'latepoint-coupons'), 'link' => false );
      $this->vars['page_header'] = __('Coupons', 'latepoint-coupons');

      $coupons = new OsCouponModel();

      $this->vars['coupons'] = $coupons->order_by('status asc, code asc')->get_results_as_models();

      $this->format_render(__FUNCTION__);
    }


    public function apply(){
      $coupon_code = strtoupper(trim($this->params['coupon_code']));
      OsStepsHelper::set_booking_object($this->params['booking']);
      OsStepsHelper::set_restrictions($this->params['restrictions']);
      $is_valid = OsCouponHelper::is_coupon_code_valid($coupon_code, OsStepsHelper::get_booking_object());
      if(is_wp_error( $is_valid )){
        $status = LATEPOINT_STATUS_ERROR;
        $response_html = $is_valid->get_error_message();
      }else{
        $status = LATEPOINT_STATUS_SUCCESS;
        $response_html = __('Coupon Code was applied to your order', 'latepoint-coupons');
      }
      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => $status, 'message' => $response_html));
      }
    }


    public function delete(){
      if(filter_var($this->params['id'], FILTER_VALIDATE_INT)){
        $coupon = new OsCouponModel($this->params['id']);
        if($coupon->delete()){
          $status = LATEPOINT_STATUS_SUCCESS;
          $response_html = __('Coupon Removed', 'latepoint-coupons');
        }else{
          $status = LATEPOINT_STATUS_ERROR;
          $response_html = __('Error Removing Coupon', 'latepoint-coupons');
        }
      }else{
        $status = LATEPOINT_STATUS_ERROR;
        $response_html = __('Error Removing Coupon', 'latepoint-coupons');
      }
      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => $status, 'message' => $response_html));
      }
    }

    public function new_form(){
      $this->vars['coupon'] = new OsCouponModel();
      $this->set_layout('none');
      $this->format_render(__FUNCTION__);
    }

    /*
      Create coupon
    */

    public function create(){
      $this->update();
    }


    /*
      Update coupon
    */

    public function update(){
      $is_new_record = (isset($this->params['coupon']['id']) && $this->params['coupon']['id']) ? false : true;
      $coupon = new OsCouponModel();
      $this->params['coupon']['rules'] = json_encode($this->params['coupon']['rules']);
      $coupon->set_data($this->params['coupon']);
      $extra_response_vars = array();

      if($coupon->save()){
        if($is_new_record){
          $response_html = __('Coupon Created. ID:', 'latepoint-coupons') . $coupon->id;
          OsActivitiesHelper::create_activity(array('code' => 'coupon_create', 'coupon_id' => $coupon->id));
        }else{
          $response_html = __('Coupon Updated. ID:', 'latepoint-coupons') . $coupon->id;
          OsActivitiesHelper::create_activity(array('code' => 'coupon_update', 'coupon_id' => $coupon->id));
        }
        $status = LATEPOINT_STATUS_SUCCESS;
        $extra_response_vars['record_id'] = $coupon->id;
      }else{
        $response_html = $coupon->get_error_messages();
        $status = LATEPOINT_STATUS_ERROR;
      }
      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => $status, 'message' => $response_html) + $extra_response_vars);
      }
    }

  }
endif;