<?php
/**
 * Plugin Name: LatePoint Addon - Timezone Selector
 * Plugin URI:  https://latepoint.com/
 * Description: LatePoint addon for timezone selector
 * Version:     1.0.8
 * Author:      LatePoint
 * Author URI:  https://latepoint.com/
 * Text Domain: latepoint-timezone-selector
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}

// If no LatePoint class exists - exit, because LatePoint plugin is required for this addon

if ( ! class_exists( 'LatePointAddonTimezoneSelector' ) ) :

/**
 * Main Addon Class.
 *
 */

class LatePointAddonTimezoneSelector {

  /**
   * Addon version.
   *
   */
  public $version = '1.0.8';
  public $db_version = '1.0.0';
  public $addon_name = 'latepoint-timezone-selector';




  /**
   * LatePoint Constructor.
   */
  public function __construct() {
    $this->define_constants();
    $this->init_hooks();
  }

  /**
   * Define LatePoint Constants.
   */
  public function define_constants() {
    $upload_dir = wp_upload_dir();

    global $wpdb;
  }


  public static function public_stylesheets() {
    return plugin_dir_url( __FILE__ ) . 'public/stylesheets/';
  }

  /**
   * Define constant if not already set.
   *
   */
  public function define( $name, $value ) {
    if ( ! defined( $name ) ) {
      define( $name, $value );
    }
  }

  /**
   * Include required core files used in admin and on the frontend.
   */
  public function includes() {

    // CONTROLLERS
    include_once(dirname( __FILE__ ) . '/lib/controllers/timezone_selector_controller.php' );

    // HELPERS

    // MODELS

  }

  public function init_hooks(){
    add_action('latepoint_includes', [$this, 'includes']);

    add_action( 'init', array( $this, 'init' ), 0 );

    add_action( 'latepoint_settings_steps_after', array( $this, 'add_timezone_settings' ), 1 );
    add_action( 'latepoint_steps_side_panel_after', array( $this, 'output_timezone_selector' ) );
    add_action( 'latepoint_available_vars_booking',[$this, 'add_timezone_vars_for_booking'], 15);
    add_action( 'latepoint_available_vars_customer',[$this, 'add_timezone_vars_for_customer'], 15);

    add_filter( 'latepoint_booking_form_classes', array( $this, 'add_booking_form_class' ) );
    add_filter( 'latepoint_replace_booking_vars', [$this, 'replace_booking_vars_for_timezone'], 10, 2);
    add_filter( 'latepoint_get_resources_grouped_by_day', [$this, 'apply_timeshift_to_resources_grouped_by_day'], 10, 5);
    add_filter( 'latepoint_timezone_name_from_session', [$this, 'get_timezone_name_for_logged_in_customer'] );

    register_activation_hook(__FILE__, [$this, 'on_activate']);
    register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);


  }

  /**
   * Init LatePoint when WordPress Initialises.
   */
  public function init() {
    // Set up localisation.
    $this->load_plugin_textdomain();
  }

  public function add_timezone_vars_for_booking(){
    echo '<li><span class="var-label">'.__('Start Date (in customer timezone):', 'latepoint-timezone-selector').'</span> <span class="var-code os-click-to-copy">{start_date_customer_timezone}</span></li>';
    echo '<li><span class="var-label">'.__('Start Time (in customer timezone):', 'latepoint-timezone-selector').'</span> <span class="var-code os-click-to-copy">{start_time_customer_timezone}</span></li>';
    echo '<li><span class="var-label">'.__('End Time (in customer timezone)', 'latepoint-timezone-selector').'</span> <span class="var-code os-click-to-copy">{end_time_customer_timezone}</span></li>';
  }


	public function apply_timeshift_to_resources_grouped_by_day($daily_resources, $booking_request, $date_from, $date_to, $settings){
		if($settings['timeshift_minutes'] != 0){
			$resources_to_be_moved = [];
			for($day_date = clone $date_from; $day_date->format('Y-m-d') <= $date_to->format('Y-m-d'); $day_date->modify('+1 day')){
				$next_day = clone $day_date;
				$next_day->modify('+1 day');
				$prev_day = clone $day_date;
				$prev_day->modify('-1 day');
				$resources_to_be_moved_to_next_day = [];
				$total_resources = count($daily_resources[$day_date->format('Y-m-d')]);
				for($i = 0; $i<$total_resources;$i++){
					$temp_resource_for_next_day_move = new \LatePoint\Misc\BookingResource();
					$temp_resource_for_next_day_move->agent_id = $daily_resources[$day_date->format('Y-m-d')][$i]->agent_id;
					$temp_resource_for_next_day_move->service_id = $daily_resources[$day_date->format('Y-m-d')][$i]->service_id;
					$temp_resource_for_next_day_move->location_id = $daily_resources[$day_date->format('Y-m-d')][$i]->location_id;

					// loop and apply timeshift to WORK TIME PERIODS
					// -----------
					$total_work_time_periods = count($daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods);
					for($j = 0; $j<$total_work_time_periods; $j++){
						$new_work_period_for_prev_day = false;
						$new_work_period_for_next_day = false;
						$daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->start_time+= $settings['timeshift_minutes'];
						$daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->end_time+= $settings['timeshift_minutes'];
						if($daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->start_time < 0 && $daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->end_time < 0) {
							// both start and end of work period should be moved to a previous day
							$new_work_period_for_prev_day = new \LatePoint\Misc\TimePeriod();
							$new_work_period_for_prev_day->start_time = 24*60 + $daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->start_time;
							$new_work_period_for_prev_day->end_time = 24*60 + $daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->end_time;
							// remove work periods from current day, because it was fully moved to previous day
							unset($daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]);
						}elseif($daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->start_time < 0){
							// only start time is leaking to previous day, create new period with a cutoff
							$new_work_period_for_prev_day = new \LatePoint\Misc\TimePeriod();
							$new_work_period_for_prev_day->start_time = 24*60 + $daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->start_time;
							$new_work_period_for_prev_day->end_time = 24*60;
							$daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->start_time = 0;
						}

						if($daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->start_time >= 24*60 && $daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->end_time >= 24*60) {
							// both start and end of work period should be moved to a next day
							$new_work_period_for_next_day = new \LatePoint\Misc\TimePeriod();
							$new_work_period_for_next_day->start_time = $daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->start_time - 24*60;
							$new_work_period_for_next_day->end_time = $daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->end_time - 24*60;
							// remove work periods from current day, because it was fully moved to next day
							unset($daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]);
						}elseif($daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->end_time >= 24*60){
							// only end time is leaking to next day, create new period with a cutoff
							$new_work_period_for_next_day = new \LatePoint\Misc\TimePeriod();
							$new_work_period_for_next_day->start_time = 0;
							$new_work_period_for_next_day->end_time = $daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->end_time - 24*60;
							$daily_resources[$day_date->format('Y-m-d')][$i]->work_time_periods[$j]->end_time = 24*60;
						}

						if($new_work_period_for_next_day){
							$temp_resource_for_next_day_move->work_time_periods[] = $new_work_period_for_next_day;
						}
						if($new_work_period_for_prev_day){
							$updated_day = clone $day_date;
							$updated_day->modify('-1 day');
							if(isset($daily_resources[$updated_day->format('Y-m-d')])){
								for($p = 0; $p<count($daily_resources[$updated_day->format('Y-m-d')]);$p++) {
									if($daily_resources[$updated_day->format('Y-m-d')][$p]->agent_id == $daily_resources[$day_date->format('Y-m-d')][$i]->agent_id
										&& $daily_resources[$updated_day->format('Y-m-d')][$p]->service_id == $daily_resources[$day_date->format('Y-m-d')][$i]->service_id
										&& $daily_resources[$updated_day->format('Y-m-d')][$p]->location_id == $daily_resources[$day_date->format('Y-m-d')][$i]->location_id){
										// same resource found - add those work periods to this resource
											// add to the end of prev day
											$daily_resources[$updated_day->format('Y-m-d')][$p]->work_time_periods[] = $new_work_period_for_prev_day;
									}
								}
							}
						}
					}

					// loop and apply timeshift to booking SLOTS
					// ----------
					$total_slots = count($daily_resources[$day_date->format('Y-m-d')][$i]->slots);
					for($j = 0; $j<$total_slots; $j++){
						$new_slot_for_prev_day = false;
						$new_slot_for_next_day = false;
						$daily_resources[$day_date->format('Y-m-d')][$i]->slots[$j]->start_time+= $settings['timeshift_minutes'];
						if($daily_resources[$day_date->format('Y-m-d')][$i]->slots[$j]->start_time < 0){
							$new_slot_for_prev_day = clone $daily_resources[$day_date->format('Y-m-d')][$i]->slots[$j];
							$new_slot_for_prev_day->start_time = 24*60 + $new_slot_for_prev_day->start_time;
							$new_slot_for_next_day->start_date = $prev_day->format('Y-m-d');
							unset($daily_resources[$day_date->format('Y-m-d')][$i]->slots[$j]);
						}elseif($daily_resources[$day_date->format('Y-m-d')][$i]->slots[$j]->start_time >= 24*60){
							$new_slot_for_next_day = clone $daily_resources[$day_date->format('Y-m-d')][$i]->slots[$j];
							$new_slot_for_next_day->start_time = $new_slot_for_next_day->start_time - 24*60;
							$new_slot_for_next_day->start_date = $next_day->format('Y-m-d');
							unset($daily_resources[$day_date->format('Y-m-d')][$i]->slots[$j]);
						}
						if($new_slot_for_next_day){
							$temp_resource_for_next_day_move->slots[] = $new_slot_for_next_day;
						}
						if($new_slot_for_prev_day){
							$updated_day = clone $day_date;
							$updated_day->modify('-1 day');
							if(isset($daily_resources[$updated_day->format('Y-m-d')])){
								for($p = 0; $p<count($daily_resources[$updated_day->format('Y-m-d')]);$p++) {
									if($daily_resources[$updated_day->format('Y-m-d')][$p]->agent_id == $daily_resources[$day_date->format('Y-m-d')][$i]->agent_id
										&& $daily_resources[$updated_day->format('Y-m-d')][$p]->service_id == $daily_resources[$day_date->format('Y-m-d')][$i]->service_id
										&& $daily_resources[$updated_day->format('Y-m-d')][$p]->location_id == $daily_resources[$day_date->format('Y-m-d')][$i]->location_id){
										// same resource found - add those work periods to this resource
										$daily_resources[$updated_day->format('Y-m-d')][$p]->slots[] = $new_slot_for_prev_day;
									}
								}
							}
						}
					}


					// loop and apply timeshift to WORK MINUTES
					// -----------
					$total_work_minutes = count($daily_resources[$day_date->format('Y-m-d')][$i]->work_minutes);
					for($j = 0; $j<$total_work_minutes; $j++){
						$new_work_minute_for_prev_day = false;
						$new_work_minute_for_next_day = false;
						$daily_resources[$day_date->format('Y-m-d')][$i]->work_minutes[$j]+= $settings['timeshift_minutes'];
						if($daily_resources[$day_date->format('Y-m-d')][$i]->work_minutes[$j] < 0){
							$new_work_minute_for_prev_day = 24*60 + $daily_resources[$day_date->format('Y-m-d')][$i]->work_minutes[$j];
							unset($daily_resources[$day_date->format('Y-m-d')][$i]->work_minutes[$j]);
						}elseif($daily_resources[$day_date->format('Y-m-d')][$i]->work_minutes[$j] >= 24*60){
							$new_work_minute_for_next_day = $daily_resources[$day_date->format('Y-m-d')][$i]->work_minutes[$j] - 24*60;
							unset($daily_resources[$day_date->format('Y-m-d')][$i]->work_minutes[$j]);
						}

						if($new_work_minute_for_next_day !== false){
							$temp_resource_for_next_day_move->work_minutes[] = $new_work_minute_for_next_day;
						}
						if($new_work_minute_for_prev_day !== false){
							$updated_day = clone $day_date;
							$updated_day->modify('-1 day');
							if(isset($daily_resources[$updated_day->format('Y-m-d')])){
								for($p = 0; $p<count($daily_resources[$updated_day->format('Y-m-d')]);$p++) {
									if($daily_resources[$updated_day->format('Y-m-d')][$p]->agent_id == $daily_resources[$day_date->format('Y-m-d')][$i]->agent_id
										&& $daily_resources[$updated_day->format('Y-m-d')][$p]->service_id == $daily_resources[$day_date->format('Y-m-d')][$i]->service_id
										&& $daily_resources[$updated_day->format('Y-m-d')][$p]->location_id == $daily_resources[$day_date->format('Y-m-d')][$i]->location_id){
										// same resource found - add those work periods to this resource
											// add to the end of prev day
											$daily_resources[$updated_day->format('Y-m-d')][$p]->work_minutes[] = $new_work_minute_for_prev_day;
									}
								}
							}
						}
					}
					// if temp resource for the next day has some data created to be moved - add it to a list of resources for next day that need to be moved
					if($temp_resource_for_next_day_move->work_time_periods || $temp_resource_for_next_day_move->slots || $temp_resource_for_next_day_move->work_minutes){
						$resources_to_be_moved_to_next_day[] = $temp_resource_for_next_day_move;
					}
				}
				if($resources_to_be_moved_to_next_day) {
					$next_day = clone $day_date;
					$next_day->modify('+1 day');
					$resources_to_be_moved[$next_day->format('Y-m-d')] = $resources_to_be_moved_to_next_day;
				}
				if(isset($resources_to_be_moved[$day_date->format('Y-m-d')])){
					foreach($resources_to_be_moved[$day_date->format('Y-m-d')] as $resource_to_be_moved){
						// loop this day resources to find a matching one and append new data to it
						$total_daily_resources = count($daily_resources[$day_date->format('Y-m-d')]);
						for($b = 0; $b<$total_daily_resources;$b++){
							if($daily_resources[$day_date->format('Y-m-d')][$b]->agent_id == $resource_to_be_moved->agent_id
								&& $daily_resources[$day_date->format('Y-m-d')][$b]->service_id == $resource_to_be_moved->service_id
								&& $daily_resources[$day_date->format('Y-m-d')][$b]->location_id == $resource_to_be_moved->location_id){
								// same resource found - add those work periods to this resource
									// add to the end of prev day
									$daily_resources[$day_date->format('Y-m-d')][$b]->work_time_periods = array_merge($resource_to_be_moved->work_time_periods, $daily_resources[$day_date->format('Y-m-d')][$b]->work_time_periods);
									$daily_resources[$day_date->format('Y-m-d')][$b]->slots = array_merge($resource_to_be_moved->slots, $daily_resources[$day_date->format('Y-m-d')][$b]->slots);
									$daily_resources[$day_date->format('Y-m-d')][$b]->work_minutes = array_merge($resource_to_be_moved->work_minutes, $daily_resources[$day_date->format('Y-m-d')][$b]->work_minutes);
							}
						}
					}
					$resources_to_be_moved[$day_date->format('Y-m-d')] = [];
				}
			}
		}
		return $daily_resources;
	}


  public function get_timezone_name_for_logged_in_customer($timezone_name){
    if(OsTimeHelper::is_timezone_saved_in_session()){
      $timezone_name = $_COOKIE[LATEPOINT_SELECTED_TIMEZONE_COOKIE];
    }else{
      if(OsAuthHelper::is_customer_logged_in()){
        $customer_timezone_name = OsMetaHelper::get_customer_meta_by_key('timezone_name', OsAuthHelper::get_logged_in_customer_id());
        if(!empty($customer_timezone_name)){
          $timezone_name = $customer_timezone_name;
        }else{
          OsMetaHelper::save_customer_meta_by_key('timezone_name', OsTimeHelper::get_wp_timezone_name(), OsAuthHelper::get_logged_in_customer_id());
          $timezone_name = OsTimeHelper::get_wp_timezone_name();
        }
      }else{
        $timezone_name = OsTimeHelper::get_wp_timezone_name();
      }
      OsTimeHelper::set_timezone_name_in_cookie($timezone_name);
    }
    return $timezone_name;
  }


  public function add_timezone_vars_for_customer(){
    echo '<li><span class="var-label">'.__('Customer Timezone', 'latepoint-timezone-selector').'</span> <span class="var-code os-click-to-copy">{customer_timezone}</span></li>';
  }

  public static function replace_booking_vars_for_timezone($text, $booking){
    $needles = ['{start_date_customer_timezone}',
                '{start_time_customer_timezone}',
                '{end_time_customer_timezone}',
                '{customer_timezone}'];

    $replacements = [$booking->nice_start_date_for_customer,
                      $booking->nice_start_time_for_customer,
                      $booking->nice_end_time_for_customer,
                      $booking->customer->get_selected_timezone_name()];
    $text = str_replace($needles, $replacements, $text);
    return $text;
  }


  public static function add_booking_form_class($classes){
    if(OsSettingsHelper::is_on('steps_show_timezone_selector')) $classes[] = 'addon-timezone-selector-active';
    return $classes;
  }

  public function output_timezone_selector($active_step_model){
    if(OsSettingsHelper::is_on('steps_show_timezone_selector')){
      echo '<div class="latepoint-timezone-selector-w" data-route-name="'.OsRouterHelper::build_route_name('timezone_selector', 'change_timezone').'">';
        echo OsFormHelper::select_field('latepoint_timezone_selector', __('Times are in:', 'latepoint-timezone-selector'), OsTimeHelper::timezones_options_list(OsTimeHelper::get_timezone_name_from_session()), OsTimeHelper::get_timezone_name_from_session());
      echo '</div>';
    }
  }

  public function add_timezone_settings(){
    echo OsFormHelper::toggler_field('settings[steps_show_timezone_selector]', __('Show timezone selector on datepicker step and customer dashboard', 'latepoint-timezone-selector'), OsSettingsHelper::is_on('steps_show_timezone_selector'));
  }

  public function load_plugin_textdomain() {
    load_plugin_textdomain('latepoint-timezone-selector', false, dirname(plugin_basename(__FILE__)) . '/languages');
  }

  public function on_deactivate(){
  }

  public function on_activate(){
    do_action('latepoint_on_addon_activate', $this->addon_name, $this->version);
  }

  public function register_addon($installed_addons){
    $installed_addons[] = ['name' => $this->addon_name, 'db_version' => $this->db_version, 'version' => $this->version];
    return $installed_addons;
  }

  public function db_sqls($sqls){
  }




}

endif;
if ( in_array( 'latepoint/latepoint.php', get_option( 'active_plugins', array() ) )  || array_key_exists('latepoint/latepoint.php', get_site_option('active_sitewide_plugins', array())) ) {
	$LATEPOINT_ADDON_TIMEZONE_SELECTOR = new LatePointAddonTimezoneSelector();
}
$latepoint_session_salt = 'ZjYwNTU0MzgtNDAwNC00OTgzLTgzMTUtNWZmNDlkNmUwNjUy';
