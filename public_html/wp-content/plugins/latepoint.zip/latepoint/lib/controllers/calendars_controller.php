<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}


if ( ! class_exists( 'OsCalendarsController' ) ) :


  class OsCalendarsController extends OsController {

    private $booking;

    function __construct(){
      parent::__construct();

      $this->action_access['public'] = array_merge($this->action_access['public'], ['load_monthly_calendar_days']);


      $this->views_folder = LATEPOINT_VIEWS_ABSPATH . 'calendars/';
      $this->vars['page_header'] = [['label' => __( 'Daily View', 'latepoint' ), 'icon' => '', 'link' => OsRouterHelper::build_link(['calendars', 'day_view'])],
                                    ['label' => __( 'Weekly View', 'latepoint' ), 'icon' => '', 'link' => OsRouterHelper::build_link(['calendars', 'week_view'])],
                                    ['label' => __( 'Monthly View', 'latepoint' ), 'icon' => '', 'link' => OsRouterHelper::build_link(['calendars', 'month_view'])]];
      if(OsAuthHelper::is_agent_logged_in()) $this->vars['page_header'][0]['link'] = OsRouterHelper::build_link(['calendars', 'day_view']);
      $this->vars['breadcrumbs'][] = array('label' => __('Appointments', 'latepoint'), 'link' => OsRouterHelper::build_link(OsRouterHelper::build_route_name('calendars', 'pending_approval') ) );
    }


    public function load_monthly_calendar_days_only(){
      $target_date = new OsWpDateTime($this->params['target_date_string']);
      $this->vars['target_date'] = $target_date;

      $this->set_layout('none');
      $this->format_render(__FUNCTION__);
    }



    public function load_monthly_calendar_days(){
      $target_date = new OsWpDateTime($this->params['target_date_string']);
      $calendar_settings = ['layout' => isset($this->params['calendar_layout']) ? $this->params['calendar_layout'] : 'classic',
	                          'timezone_name' => isset($this->params['timezone_name']) ? $this->params['timezone_name'] : false];

      if(!isset($this->params['allow_full_access'])){
        $calendar_settings['earliest_possible_booking'] = OsSettingsHelper::get_settings_value('earliest_possible_booking', false);
        $calendar_settings['latest_possible_booking'] = OsSettingsHelper::get_settings_value('latest_possible_booking', false);
      }

			$booking = new OsBookingModel();
			$booking->set_data($this->params['booking']);

			$booking_request = \LatePoint\Misc\BookingRequest::create_from_booking_model($booking);

      $this->format_render('_monthly_calendar_days', [ 'target_date' => $target_date,
	                                                                'calendar_settings' => $calendar_settings,
	                                                                'booking_request' => $booking_request]);
    }

    function not_used_day_view(){
      $this->vars['breadcrumbs'][] = array('label' => __('Daily View', 'latepoint'), 'link' => false );

      $services = new OsServiceModel();
      $agents = new OsAgentModel();

      if($this->logged_in_agent_id){
        $agents->where(['id' => $this->logged_in_agent_id]);
        $this->params['selected_agent_id'] = $this->logged_in_agent_id;
      }

      $agents_models = $agents->get_results_as_models();
      $selected_agent = $agents_models[0];
      if(isset($this->params['selected_agent_id'])){
        $selected_agent = $agents->load_by_id($this->params['selected_agent_id']);
      }
      $selected_agent_id = (isset($selected_agent)) ? $selected_agent->id : false;

      $services_models = $services->get_results_as_models();
      $this->vars['services'] = $services_models;

      if($services_models){
        if(isset($this->params['selected_service_id'])){
          $selected_service = $services->load_by_id($this->params['selected_service_id']);
        }else{
          $selected_service = $services_models[0];
        }
      }else{
        $selected_service = false;
      }


      $timeblock_interval = ($selected_service) ? $selected_service->get_timeblock_interval() : OsSettingsHelper::get_default_timeblock_interval();
      $selected_service_id = ($selected_service) ? $selected_service->id : false;

      $this->vars['agents'] = $agents_models;
      $this->vars['selected_service'] = $selected_service;
      $this->vars['selected_agent'] = $selected_agent;
      $this->vars['selected_agent_id'] = $selected_agent_id;
      $this->vars['selected_service_id'] = $selected_service_id;

      $locations = OsLocationHelper::get_locations(OsAuthHelper::get_logged_in_agent_id());
      $this->vars['locations'] = $locations;
      if($locations){
        // show all locations option if agent can only be present at one place - it means he does not have overlapping appointments on the calendar
        $default_location_id = OsSettingsHelper::is_on('one_location_at_time') ? false : $locations[0]->id;
        $selected_location_id = isset($this->params['location_id']) ? $this->params['location_id'] : $default_location_id;
      }else{
        $selected_location_id = false;
      }

      $selected_location = $selected_location_id ? new OsLocationModel($selected_location_id) : false;
      $this->vars['selected_location'] = $selected_location;
      $this->vars['selected_location_id'] = $selected_location_id;

      $this->vars['timeblock_interval'] = $timeblock_interval;

      $today_date = new OsWpDateTime('today');

      if(isset($this->params['target_date'])){
        $target_date = new OsWpDateTime($this->params['target_date']);
      }else{
        $target_date = new OsWpDateTime('today');
      }

			$this->vars['is_today'] = ($target_date->format('Y-m-d') == $today_date->format('Y-m-d'));


      $this->vars['nice_selected_date'] = OsTimeHelper::nice_date($target_date->format('Y-m-d'));

      $calendar_prev = clone $target_date;
      $calendar_next = clone $target_date;
      $calendar_start = clone $target_date;
      $calendar_end = clone $target_date;

      $this->vars['today_date'] = $today_date;
      $this->vars['target_date'] = $target_date;

      $this->vars['calendar_prev'] = $calendar_prev->modify('- 7 days');
      $this->vars['calendar_next'] = $calendar_next->modify('+ 7 days');





      $work_periods_arr = OsWorkPeriodsHelper::get_work_periods(new \LatePoint\Misc\Filter(['agent_id' => $selected_agent_id,
                                                              'date_from' => $target_date->format('Y-m-d'),
                                                              'location_id' => $selected_location_id,
                                                              'week_day' => $target_date->format('N')]));
      $this->vars['work_periods_arr'] = $work_periods_arr;

      $bookings = OsBookingHelper::get_bookings(new \LatePoint\Misc\Filter(['date_from' => $target_date->format('Y-m-d'), 'agent_id' => $selected_agent_id, 'location_id' => $selected_location_id]));

      list($this->vars['work_start_minutes'], $this->vars['work_end_minutes']) = OsWorkPeriodsHelper::get_work_start_end_time($work_periods_arr);
      list($this->vars['calendar_start_minutes'], $this->vars['calendar_end_minutes']) = OsBookingHelper::get_calendar_start_end_time([$bookings], $this->vars['work_start_minutes'], $this->vars['work_end_minutes']);

      $this->vars['work_total_minutes'] = $this->vars['work_end_minutes'] - $this->vars['work_start_minutes'];
      $this->vars['work_total_minutes'] = $this->vars['calendar_end_minutes'] - $this->vars['calendar_start_minutes'];





      $this->vars['bookings'] = $bookings;
      $this->vars['total_bookings'] = $bookings ? count($bookings) : 0;
      $this->vars['total_customers'] = OsBookingHelper::get_total_customers_for_date($target_date->format('Y-m-d'), ['agent_id' => $selected_agent_id, 'location_id' => $selected_location_id]);
      $this->vars['total_revenue'] = OsBookingHelper::get_stat_for_period('price', $target_date->format('Y-m-d'), $target_date->format('Y-m-d'), false, false, $selected_agent_id, $selected_location_id);
      $this->vars['total_openings'] = OsAgentHelper::count_openings_for_date($selected_agent, $selected_service, $selected_location, $target_date->format('Y-m-d'));

      $this->format_render(__FUNCTION__);
    }


    function day_view(){
      $this->vars['breadcrumbs'][] = array('label' => __('Daily View', 'latepoint'), 'link' => false );

      $services = new OsServiceModel();
      $agents = new OsAgentModel();

      if($this->logged_in_agent_id){
        $agents->where(['id' => $this->logged_in_agent_id]);
      }
      $agents_models = $agents->get_results_as_models();
      $services_models = OsServiceHelper::get_services(OsAuthHelper::get_logged_in_agent_id());
      $locations_models = OsLocationHelper::get_locations(OsAuthHelper::get_logged_in_agent_id());

      $this->vars['services']   = $services_models;
      $this->vars['locations']  = $locations_models;
      $this->vars['agents']     = $agents_models;

      if($services_models){
        if(isset($this->params['service_id'])){
          $selected_service = $services->load_by_id($this->params['service_id']);
        }else{
          $selected_service = $services_models[0];
        }
      }else{
        $selected_service = false;
      }


      if($locations_models){
        // show all locations option if agent can only be present at one place - because it means he does not have overlapping appointments on the calendar
        $default_location_id = OsSettingsHelper::is_on('one_location_at_time') ? false : $locations_models[0]->id;
        $selected_location_id = isset($this->params['location_id']) ? $this->params['location_id'] : $default_location_id;
      }else{
        $selected_location_id = false;
      }

      $this->vars['selected_location'] = $selected_location_id ? new OsLocationModel($selected_location_id) : false;
      $this->vars['selected_location_id'] = $selected_location_id;

      $timeblock_interval = OsSettingsHelper::get_default_timeblock_interval();
      $selected_service_id = ($selected_service) ? $selected_service->id : false;

      $this->vars['selected_service'] = $selected_service;
      $this->vars['selected_service_id'] = $selected_service_id;


      $today_date = new OsWpDateTime('today');

      if(isset($this->params['target_date'])){
        $target_date = new OsWpDateTime($this->params['target_date']);
      }else{
        $target_date = new OsWpDateTime('today');
      }

      $this->vars['nice_selected_date'] = OsTimeHelper::nice_date($target_date->format('Y-m-d'));

      $this->vars['today_date'] = $today_date;
      $this->vars['target_date'] = $target_date;

			// we are using two separate booking requests because the calendar on top has to generate availability timeline,
	    // which can only be generated if we know service to check for. The second booking request is used to retrieve
	    // shared resources for all services and locations (unless specific location is selected)
			$availability_booking_request = new \LatePoint\Misc\BookingRequest();
			$general_booking_request = new \LatePoint\Misc\BookingRequest();
			if($selected_location_id){
				$availability_booking_request->location_id = $selected_location_id;
				$general_booking_request->location_id = $selected_location_id;
			}
			if($selected_service){
				$availability_booking_request->service_id = $selected_service->id;
				// TODO add capacity and duration select box and POST params if multiple durations in a service
				$availability_booking_request->duration = $selected_service->duration;
				$timeblock_interval = $selected_service->get_timeblock_interval();
			}


      if($this->logged_in_agent_id) {
				$availability_booking_request->agent_id = $this->logged_in_agent_id;
				$general_booking_request->agent_id = $this->logged_in_agent_id;
      }

			$resources = OsResourceHelper::get_resources_grouped_by_day($general_booking_request, $target_date, $target_date);
			$availability_resources = OsResourceHelper::get_resources_grouped_by_day($availability_booking_request, $target_date, $target_date);
			$work_boundaries = OsResourceHelper::get_work_boundaries_for_resources($resources[$target_date->format('Y-m-d')]);
			$work_total_minutes = $work_boundaries->end_time - $work_boundaries->start_time;

			$this->vars['resources'] = $resources;
			$this->vars['work_boundaries'] = $work_boundaries;
      $this->vars['timeblock_interval'] = $timeblock_interval;
			$calendar_min_height = OsSettingsHelper::get_day_calendar_min_height();
			$this->vars['calendar_min_height'] = $calendar_min_height;

			if($target_date->format('Y-m-d') == $today_date->format('Y-m-d')){
				$time_now = OsTimeHelper::now_datetime_object();
				$time_now_in_minutes = OsTimeHelper::convert_datetime_to_minutes($time_now);
				if(($time_now_in_minutes<=$work_boundaries->end_time && $time_now_in_minutes>=$work_boundaries->start_time)){
					$this->vars['time_now_label'] = $time_now->format(OsTimeHelper::get_time_format());
					// agents row with avatars and margin below - offset that needs to be accounted for when calculating "time now" indicator position
					$agents_row_height = 70;
					$this->vars['time_now_indicator_top_offset'] = $calendar_min_height * (($time_now_in_minutes - $work_boundaries->start_time) / $work_total_minutes * 100) / 100 + $agents_row_height;
					$this->vars['show_today_indicator'] = true;
				}else{
					$this->vars['show_today_indicator'] = false;
				}
			}else{
				$this->vars['show_today_indicator'] = false;
			}

      $bookings = [];
			$agent_work_time_periods = [];
      if($agents_models){
        foreach($agents_models as $agent){
					$agent_work_time_periods[$agent->id] = [];
          $args = ['agent_id' => $agent->id];
          if($selected_location_id) $args['location_id'] = $selected_location_id;
          $bookings[$agent->id] = OsBookingHelper::get_bookings_for_date($target_date->format('Y-m-d'), $args);
        }
				foreach($availability_resources[$target_date->format('Y-m-d')] as $resource){
					$agent_work_time_periods[$resource->agent_id] = array_merge($agent_work_time_periods[$resource->agent_id], $resource->work_time_periods);
				}
      }


      $this->vars['agent_work_time_periods'] = $agent_work_time_periods;
      $this->vars['bookings'] = $bookings;

      $this->vars['work_total_minutes'] = $work_total_minutes;


	    $this->vars['calendar_settings'] = ['locations' => $locations_models,
																			    'services' => $services_models,
								                          'number_of_months_to_preload' => 0,
								                          'layout' => 'horizontal',
								                          'allow_full_access' => true,
								                          'highlight_target_date' => true];
			$this->vars['availability_booking_request'] = $availability_booking_request;
			$this->vars['general_booking_request'] = $general_booking_request;

      $this->format_render(__FUNCTION__);
    }


	  /**
	   * Weekly calendar for single agent
	   */
    function week_view(){
      $this->vars['breadcrumbs'][] = array('label' => __('Weekly Calendar', 'latepoint'), 'link' => false );

      $services = new OsServiceModel();
      $services_models = $services->get_results_as_models();
      $this->vars['services'] = $services_models;

      if($services_models){
        if(isset($this->params['selected_service_id'])){
          $selected_service = $services->load_by_id($this->params['selected_service_id']);
        }else{
          $selected_service = $services_models[0];
        }
      }else{
        $selected_service = false;
      }

      $selected_service_id = ($selected_service) ? $selected_service->id : false;

      $agents = new OsAgentModel();


      if($this->logged_in_agent_id){
        $this->params['agent_id'] = $this->logged_in_agent_id;
        $agents->where(['id' => $this->logged_in_agent_id]);
      }

      $agents_arr = $agents->get_results();

      $this->vars['agents'] = $agents_arr;
      if(isset($this->params['agent_id'])){
        $selected_agent = $agents->load_by_id($this->params['agent_id']);
      }else{
        if(isset($agents_arr) && !empty($agents_arr)){
          $selected_agent = $agents->load_by_id($agents_arr[0]->id);
        }else{
          $selected_agent = false;
        }
      }

      $selected_agent_id = (isset($selected_agent) && $selected_agent) ? $selected_agent->id : false;
      $this->vars['selected_agent_id'] = $selected_agent_id;
      $this->vars['selected_agent'] = $selected_agent;

      $locations = OsLocationHelper::get_locations(OsAuthHelper::get_logged_in_agent_id());
      $this->vars['locations'] = $locations;
      if($locations){
        // show all locations option if agent can only be present at one place - it means he does not have overlapping appointments on the calendar
        $default_location_id = OsSettingsHelper::is_on('one_location_at_time') ? false : $locations[0]->id;
        $selected_location_id = (isset($this->params['location_id']) && is_numeric($this->params['location_id'])) ? $this->params['location_id'] : $default_location_id;
      }else{
        $selected_location_id = false;
      }

      $this->vars['selected_location'] = $selected_location_id ? new OsLocationModel($selected_location_id) : false;
      $this->vars['selected_location_id'] = $selected_location_id;

      $this->vars['timeblock_interval'] = OsSettingsHelper::get_default_timeblock_interval();

      $today_date = new OsWpDateTime('today');

      if(isset($this->params['target_date'])){
        $target_date = new OsWpDateTime($this->params['target_date']);
      }else{
        $target_date = new OsWpDateTime('today');
      }

      $calendar_prev = clone $target_date;
      $calendar_next = clone $target_date;
      $calendar_start = clone $target_date;
      $calendar_end = clone $target_date;

      $this->vars['today_date'] = $today_date;
      $this->vars['target_date'] = $target_date;

			$calendar_start->modify('monday this week');
			$calendar_end->modify('sunday this week');



      $this->vars['calendar_start'] = $calendar_start;
      $this->vars['calendar_end'] = $calendar_end;

      $this->vars['calendar_prev'] = $calendar_prev->modify('- 7 days');
      $this->vars['calendar_next'] = $calendar_next->modify('+ 7 days');


			$booking_request = new \LatePoint\Misc\BookingRequest();
			if($selected_service_id) $booking_request->service_id = $selected_service_id;
			if($selected_location_id) $booking_request->location_id = $selected_location_id;
			if($selected_agent_id) $booking_request->agent_id = $selected_agent_id;

	    $resources = OsResourceHelper::get_resources_grouped_by_day($booking_request, $calendar_start, $calendar_end);
	    $work_boundaries = OsResourceHelper::get_work_boundaries_for_groups_of_resources($resources);


			$day_work_time_periods = [];
			$daily_bookings = [];
	    for($day_date=clone $calendar_start; $day_date<=$calendar_end; $day_date->modify('+1 day')) {
				$filter = new \LatePoint\Misc\Filter(['date_from' => $day_date->format('Y-m-d'),
																							'agent_id' => $selected_agent_id,
																							'location_id' => $selected_location_id,
																							'statuses' => OsCalendarHelper::booking_statuses_to_display_on_calendar()
																							]);
				$daily_bookings[$day_date->format('Y-m-d')] = OsBookingHelper::get_bookings($filter, true);

				$day_work_time_periods[$day_date->format('Y-m-d')] = [];
				foreach($resources[$day_date->format('Y-m-d')] as $daily_resources){
			    $day_work_time_periods[$day_date->format('Y-m-d')] = array_merge($day_work_time_periods[$day_date->format('Y-m-d')], $daily_resources->work_time_periods);
				}
	    }
	    $this->vars['day_work_time_periods'] = $day_work_time_periods;
	    $this->vars['daily_bookings'] = $daily_bookings;
	    $this->vars['resources'] = $resources;
	    $this->vars['work_boundaries'] = $work_boundaries;
      $this->vars['work_total_minutes'] = $work_boundaries->end_time - $work_boundaries->start_time;


      $this->format_render(__FUNCTION__);
    }



	  /**
	   * Monthly Calendar
	   */
    function month_view(){
      $this->vars['breadcrumbs'] = [];

      if(isset($this->params['month']) && isset($this->params['year'])){
        $requested_year_month = implode('-', [$this->params['year'], $this->params['month']]);
        $this->vars['calendar_only'] = true;
      }else{
        $this->vars['calendar_only'] = false;
        $requested_year_month = implode('-', [OsTimeHelper::today_date('Y'), OsTimeHelper::today_date('m')]);
      }
			$calendar_start = new OsWpDateTime('first day of '.$requested_year_month);
			$calendar_end = new OsWpDateTime('last day of '.$requested_year_month);


      $services = new OsServiceModel();
      $services_models = OsServiceHelper::get_services(OsAuthHelper::get_logged_in_agent_id());
			$this->vars['services'] = $services_models;

      if($services_models){
        $selected_service = (isset($this->params['service_id'])) ? $services->load_by_id($this->params['service_id']) : $services_models[0];
      }else{
        $selected_service = false;
      }

      $selected_service_id = ($selected_service) ? $selected_service->id : false;

      $agents = new OsAgentModel();

      if($this->logged_in_agent_id){
        $agents->where(['id' => $this->logged_in_agent_id]);
      }
      $agents = $agents->get_results_as_models();

      $locations = OsLocationHelper::get_locations(OsAuthHelper::get_logged_in_agent_id());
      $this->vars['locations'] = $locations;
      if($locations){
        // show all locations option if agent can only be present at one place - it means he does not have overlapping appointments on the calendar
        $default_location_id = OsSettingsHelper::is_on('one_location_at_time') ? false : $locations[0]->id;
        $selected_location_id = isset($this->params['location_id']) ? $this->params['location_id'] : $default_location_id;
      }else{
        $selected_location_id = false;
      }


			$this->vars['date_format'] = OsSettingsHelper::get_readable_date_format(true);
      $this->vars['selected_location'] = $selected_location_id ? new OsLocationModel($selected_location_id) : false;
      $this->vars['selected_location_id'] = $selected_location_id;
      
      $this->vars['calendar_start'] = $calendar_start;
      $this->vars['calendar_end'] = $calendar_end;


			$query_agent_ids = [];
			$bookings_grouped_by_date_and_agent = [];
			foreach($agents as $agent){
				$query_agent_ids[] = $agent->id;
		    for($day_date=clone $calendar_start; $day_date<=$calendar_end; $day_date->modify('+1 day')) {
					// fill in all days and agents bookings with blanks
					$bookings_grouped_by_date_and_agent[$day_date->format('Y-m-d')][$agent->id] = [];
		    }
			}
			$bookings = OsBookingHelper::get_bookings(new \LatePoint\Misc\Filter(['date_from' => $calendar_start->format('Y-m-d'),
																																						'date_to' => $calendar_end->format('Y-m-d'),
																																						'agent_id' => $query_agent_ids,
																																						'location_id' => $selected_location_id,
																							'statuses' => OsCalendarHelper::booking_statuses_to_display_on_calendar()]), true);
			foreach($bookings as $booking){
				$bookings_grouped_by_date_and_agent[$booking->start_date][$booking->agent_id][] = $booking;
			}

      $this->vars['bookings_grouped_by_date_and_agent'] = $bookings_grouped_by_date_and_agent;
      $this->vars['agents'] = $agents;


			$booking_request = new \LatePoint\Misc\BookingRequest();
			if($selected_location_id) $booking_request->location_id = $selected_location_id;
			if($selected_service_id) $booking_request->service_id = $selected_service_id;
			$this->vars['booking_request'] = $booking_request;

	    $resources = OsResourceHelper::get_resources_grouped_by_day($booking_request, $calendar_start, $calendar_end);
	    $work_boundaries = OsResourceHelper::get_work_boundaries_for_groups_of_resources($resources);

      $this->vars['resources'] = $resources;
      $this->vars['work_boundaries'] = $work_boundaries;
      $this->vars['work_total_minutes'] = $work_boundaries->end_time - $work_boundaries->start_time;


      $this->format_render(__FUNCTION__);
    }



  }

endif;