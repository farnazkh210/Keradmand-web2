<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}


if ( ! class_exists( 'OsDashboardController' ) ) :


  class OsDashboardController extends OsController {

    private $booking;

    function __construct(){
      parent::__construct();

      $this->views_folder = LATEPOINT_VIEWS_ABSPATH . 'dashboard/';
      $this->vars['page_header'] = __('Dashboard', 'latepoint');
    }

    public function for_agent(){
      if(!$this->logged_in_agent_id) return;

      $this->vars['page_header'] = false;

      ob_start();
      $this->widget_bookings_and_availability_timeline();
      $this->vars['widget_bookings_and_availability_timeline'] = ob_get_clean();

      ob_start();
      $this->widget_daily_bookings_chart();
      $this->vars['widget_daily_bookings_chart'] = ob_get_clean();

      ob_start();
      $this->widget_upcoming_appointments(3);
      $this->vars['widget_upcoming_appointments'] = ob_get_clean();

      $this->set_layout('admin');
      $this->format_render(__FUNCTION__);
    }



    /*
      Index
    */

    public function index(){

      $this->vars['page_header'] = false;

      ob_start();
      $this->widget_bookings_and_availability_timeline();
      $this->vars['widget_bookings_and_availability_timeline'] = ob_get_clean();

      ob_start();
      $this->widget_daily_bookings_chart();
      $this->vars['widget_daily_bookings_chart'] = ob_get_clean();

      ob_start();
      $this->widget_upcoming_appointments(3);
      $this->vars['widget_upcoming_appointments'] = ob_get_clean();

      $this->set_layout('admin');
      $this->format_render(__FUNCTION__);
    }

    public function widget_stats($date_from = false, $date_to = false){
      if($date_from == false){
        $date_from = isset($this->params['date_from']) ? OsWpDateTime::os_createFromFormat('Y-m-d', $this->params['date_from']) : new OsWpDateTime('-10 days');
      }
      if($date_to == false){
        $date_to = isset($this->params['date_to']) ? OsWpDateTime::os_createFromFormat('Y-m-d', $this->params['date_to']) : new OsWpDateTime('now');
      }

      $this->vars['date_from'] = $date_from->format('Y-m-d');
      $this->vars['date_to'] = $date_to->format('Y-m-d');

      $this->vars['date_period_string'] = OsTimeHelper::format_date_with_locale(OsSettingsHelper::get_readable_date_format(), $date_from).' - '.OsTimeHelper::format_date_with_locale(OsSettingsHelper::get_readable_date_format(), $date_to);

      $this->set_layout('none');
      $this->format_render(__FUNCTION__);
    }


    public function widget_upcoming_appointments($limit = 3){
      $agents = new OsAgentModel();
      $services = new OsServiceModel();
      $bookings = new OsBookingModel();

      $selected_agent_id = isset($this->params['agent_id']) ? $this->params['agent_id'] : false;
      if($this->logged_in_agent_id) $selected_agent_id = $this->logged_in_agent_id;

      $selected_service_id = isset($this->params['service_id']) ? $this->params['service_id'] : false;
      $selected_location_id = isset($this->params['location_id']) ? $this->params['location_id'] : false;

      $this->vars['upcoming_bookings'] = $bookings->get_upcoming_bookings($selected_agent_id, false, $selected_service_id, $selected_location_id, $limit);

      if($this->logged_in_agent_id) $agents->where(['id' => $this->logged_in_agent_id]);
      $this->vars['agents'] = $agents->get_results_as_models();

      $services = OsServiceHelper::get_services(OsAuthHelper::get_logged_in_agent_id());
      $this->vars['services'] = $services;

      $this->vars['selected_agent_id'] = $selected_agent_id;
      $this->vars['selected_service_id'] = $selected_service_id;
      $this->vars['selected_location_id'] = $selected_location_id;

      $locations = OsLocationHelper::get_locations(OsAuthHelper::get_logged_in_agent_id());
      $this->vars['locations'] = $locations;

      $this->set_layout('none');
      $this->format_render(__FUNCTION__);
    }



    public function widget_daily_bookings_chart($date_from = false, $date_to = false){
      if($date_from == false){
        $date_from = isset($this->params['date_from']) ? OsWpDateTime::os_createFromFormat('Y-m-d', $this->params['date_from']) : new OsWpDateTime('-1 month');
      }
      if($date_to == false){
        $date_to = isset($this->params['date_to']) ? OsWpDateTime::os_createFromFormat('Y-m-d', $this->params['date_to']) : new OsWpDateTime('now');
      }

      $agent_id = ($this->logged_in_agent_id) ? ($this->logged_in_agent_id) : (isset($this->params['agent_id']) ? $this->params['agent_id'] : false);
      $service_id = isset($this->params['service_id']) ? $this->params['service_id'] : false;

      $locations = OsLocationHelper::get_locations(OsAuthHelper::get_logged_in_agent_id());
      $this->vars['locations'] = $locations;
      $selected_location_id = isset($this->params['location_id']) ? $this->params['location_id'] : false;
      $this->vars['selected_location_id'] = $selected_location_id;

      $daily_bookings = OsBookingHelper::get_total_bookings_per_day_for_period($date_from->format('Y-m-d'), $date_to->format('Y-m-d'), $service_id, $agent_id, $selected_location_id);

      $daily_chart_data = [];
      // fill data array with all the days
      for($day_date=clone $date_from; $day_date<=$date_to; $day_date->modify('+1 day')){
        $daily_chart_data[OsTimeHelper::get_nice_date_with_optional_year($day_date->format('Y-m-d'), false)] = 0;
      }
      // update the days with count of bookings
      foreach($daily_bookings as $bookings_for_day){
        $daily_chart_data[OsTimeHelper::get_nice_date_with_optional_year(date( 'Y-m-d', strtotime($bookings_for_day->start_date)), false)] = $bookings_for_day->bookings_per_day;
      }

			$filter = new \LatePoint\Misc\Filter(['service_id' => $service_id, 'agent_id' => $agent_id, 'location_id' => $selected_location_id]);

      $this->vars['total_bookings'] = OsBookingHelper::get_stat_for_period('bookings', $date_from->format('Y-m-d'), $date_to->format('Y-m-d'), false, $service_id, $agent_id, $selected_location_id);
      $this->vars['total_price'] = OsBookingHelper::get_stat_for_period('price', $date_from->format('Y-m-d'), $date_to->format('Y-m-d'), false, $service_id, $agent_id, $selected_location_id);
      $this->vars['total_duration'] = OsBookingHelper::get_stat_for_period('duration', $date_from->format('Y-m-d'), $date_to->format('Y-m-d'), false, $service_id, $agent_id, $selected_location_id);
      $this->vars['total_new_customers'] = OsBookingHelper::get_new_customer_stat_for_period($date_from, $date_to, $filter);

      $day_difference = $date_from->diff($date_to);
      $day_difference = ($day_difference->d > 0) ? $day_difference->d : 1;

      $prev_date_from = clone $date_from;
      $prev_date_from->modify('-'.$day_difference.' days');
      $prev_date_to = clone $date_to;
      $prev_date_to->modify('-'.$day_difference.' days');

      $this->vars['prev_total_bookings'] = OsBookingHelper::get_stat_for_period('bookings', $prev_date_from->format('Y-m-d'), $prev_date_to->format('Y-m-d'), false, $service_id, $agent_id, $selected_location_id);
      $this->vars['prev_total_price'] = OsBookingHelper::get_stat_for_period('price', $prev_date_from->format('Y-m-d'), $prev_date_to->format('Y-m-d'), false, $service_id, $agent_id, $selected_location_id);
      $this->vars['prev_total_duration'] = OsBookingHelper::get_stat_for_period('duration', $prev_date_from->format('Y-m-d'), $prev_date_to->format('Y-m-d'), false, $service_id, $agent_id, $selected_location_id);
      $this->vars['prev_total_new_customers'] = OsBookingHelper::get_new_customer_stat_for_period($prev_date_from, $prev_date_to, $filter);


      $agents = new OsAgentModel();
      $services = new OsServiceModel();
      if($this->logged_in_agent_id) $agents->where(['id' => $this->logged_in_agent_id]);

      $this->vars['agents'] = $agents->get_results_as_models();
      $this->vars['services'] = ($this->logged_in_agent) ? $this->logged_in_agent->get_services() : $services->get_results_as_models();

      $this->vars['agent_id'] = $agent_id;
      $this->vars['service_id'] = $service_id;

      $this->vars['date_from'] = $date_from->format('Y-m-d');
      $this->vars['date_to'] = $date_to->format('Y-m-d');

      $this->vars['daily_bookings_chart_labels_string'] = implode(',', array_keys($daily_chart_data));
      $this->vars['daily_bookings_chart_data_values_string'] = implode(',', array_values($daily_chart_data));

      $pie_labels = [];
      $pie_colors = [];
      $pie_values = [];
      $pie_chart_data = OsBookingHelper::get_stat_for_period('bookings', $date_from->format('Y-m-d'), $date_to->format('Y-m-d'), 'service_id', $service_id, $agent_id, $selected_location_id);
      foreach($pie_chart_data as $pie_data){
        $service = new OsServiceModel($pie_data['service_id']);
        $pie_labels[] = $service->name;
        $pie_colors[] = $service->bg_color;
        $pie_values[] = $pie_data['stat'];
      }

      $this->vars['pie_chart_data'] = ['labels' => $pie_labels, 'colors' => $pie_colors, 'values' => $pie_values];

      $this->vars['date_period_string'] = OsTimeHelper::format_date_with_locale(OsSettingsHelper::get_readable_date_format(), $date_from).' - '.OsTimeHelper::format_date_with_locale(OsSettingsHelper::get_readable_date_format(), $date_to);

      $this->set_layout('none');
      $this->format_render(__FUNCTION__);
    }


    public function widget_agent_availability_timeline_for_period($period_length_in_days = 8){
      $agent = OsAuthHelper::get_logged_in_agent();
      $services = new OsServiceModel();
      $services = ($this->logged_in_agent) ? $this->logged_in_agent->get_services() : $services->get_results_as_models();

      if($services){
        $selected_service_id = isset($this->params['service_id']) ? $this->params['service_id'] : $services[0]->id;
      }else{
        $selected_service_id = false;
      }
      $this->vars['service_id'] = $selected_service_id;

      $selected_service = new OsServiceModel($selected_service_id);
      $this->vars['selected_service'] = $selected_service;


      $locations = OsLocationHelper::get_locations(OsAuthHelper::get_logged_in_agent_id());
      $this->vars['locations'] = $locations;
      if($locations){
        $selected_location_id = isset($this->params['location_id']) ? $this->params['location_id'] : $locations[0]->id;
      }else{
        $selected_location_id = false;
      }

      $this->vars['selected_location_id'] = $selected_location_id;
      $selected_location = $selected_location_id ? new OsLocationModel($selected_location_id) : false;
      $this->vars['selected_location'] = $selected_location;

      $calendar_start_date = isset($this->params['date_from']) ? new OsWpDateTime($this->params['date_from']) : new OsWpDateTime('today');
      $calendar_end_date = clone $calendar_start_date;
      $calendar_end_date->modify('+'.$period_length_in_days.' days');

			$booking_request = new \LatePoint\Misc\BookingRequest();
			if($this->logged_in_agent_id){
				$booking_request->agent_id = $this->logged_in_agent_id;
			}

      $work_periods = OsWorkPeriodsHelper::get_work_periods(new \LatePoint\Misc\Filter(['date_from' => $calendar_start_date->format('Y-m-d'), 'date_to' => $calendar_end_date->format('Y-m-d'), 'service_id' => $selected_service_id, 'agent_id' => $agent->id, 'location_id' => $selected_location_id]));

			$resources = OsResourceHelper::get_resources_grouped_by_day($booking_request, $calendar_start_date, $calendar_end_date);
			$work_boundaries = OsResourceHelper::get_work_boundaries_for_groups_of_resources($resources);

      $this->vars['services'] = $services;

      $this->vars['show_days_only'] = isset($this->params['show_days_only']) ? true : false;

      $this->vars['timeblock_interval'] = $selected_service->get_timeblock_interval();
      $this->vars['days_availability_html'] = OsBookingHelper::get_quick_availability_days($calendar_start_date, $calendar_end_date, $booking_request, $resources, ['work_boundaries' => $work_boundaries] );
      $this->vars['target_date'] = $calendar_start_date->format('Y-m-d');
      $this->vars['target_date_string'] = OsTimeHelper::format_date_with_locale(OsSettingsHelper::get_readable_date_format(), $calendar_start_date);

      $this->set_layout('none');
      $this->format_render(__FUNCTION__);
    }

    public function widget_agents_availability_timeline(){
			$booking_request = new \LatePoint\Misc\BookingRequest();
			if($this->logged_in_agent_id){
				$booking_request->agent_id = $this->logged_in_agent_id;
			}
			$connections = OsConnectorHelper::get_connections_that_satisfy_booking_request($booking_request);
			if($connections){
				$agent_ids = [];
				$service_ids = [];
				$location_ids = [];
				foreach($connections as $connection){
					$agent_ids[] = $connection->agent_id;
					$service_ids[] = $connection->service_id;
					$location_ids[] = $connection->location_id;
				}
				$agent_ids = array_unique($agent_ids);
				$service_ids = array_unique($service_ids);
				$location_ids = array_unique($location_ids);

	      $agents = new OsAgentModel();
	      $services = new OsServiceModel();
	      $locations = new OsLocationModel();
				$agents = $agents->where(['id' => $agent_ids])->get_results_as_models();
				$locations = $locations->where(['id' => $location_ids])->get_results_as_models();
				$services = $services->where(['id' => $service_ids])->get_results_as_models();
				$booking_request = new \LatePoint\Misc\BookingRequest();
				// get selected service and location from params or pick first one from list if params not passed
				$booking_request->service_id = (isset($this->params['service_id']) && in_array($this->params['service_id'], $service_ids)) ? $this->params['service_id'] : $services[0]->id;
				$booking_request->location_id = (isset($this->params['location_id']) && in_array($this->params['location_id'], $location_ids)) ? $this->params['location_id'] : $locations[0]->id;

	      $target_date = isset($this->params['date_from']) ? OsWpDateTime::os_createFromFormat('Y-m-d', $this->params['date_from']) : new OsWpDateTime('now');
				$booking_request->start_date = $target_date->format('Y-m-d');

				$agents_resources = [];
				foreach($agent_ids as $agent_id){
					$agent_booking_request = clone $booking_request;
					$agent_booking_request->agent_id = $agent_id;
					$daily_resources = OsResourceHelper::get_resources_grouped_by_day($agent_booking_request, $target_date);
					$agents_resources['agent_'.$agent_id] = $daily_resources[$target_date->format('Y-m-d')];
				}
				$this->vars['agents_resources'] = $agents_resources;
				$this->vars['timeline_boundaries'] = OsResourceHelper::get_work_boundaries_for_groups_of_resources($agents_resources);

	      $this->vars['agents'] = $agents;
	      $this->vars['services'] = $services;
	      $this->vars['locations'] = $locations;
	      $this->vars['booking_request'] = $booking_request;
	      $this->vars['target_date'] = $target_date->format('Y-m-d');
	      $this->vars['target_date_string'] = OsTimeHelper::format_date_with_locale(OsSettingsHelper::get_readable_date_format(), $target_date);
			}

			$this->vars['connections'] = $connections;
      $this->set_layout('none');
      $this->format_render(__FUNCTION__);
    }


    public function widget_bookings_and_availability_timeline(){
      $target_date = isset($this->params['date_from']) ? OsWpDateTime::os_createFromFormat('Y-m-d', $this->params['date_from']) : new OsWpDateTime('now');

      $services = new OsServiceModel();
      $agents = new OsAgentModel();

      if($this->logged_in_agent_id){
        $agents->where(['id' => $this->logged_in_agent_id]);
      }
      $agents_models = $agents->get_results_as_models();
      $services_models = OsServiceHelper::get_services(OsAuthHelper::get_logged_in_agent_id());
      $locations_models = OsLocationHelper::get_locations(OsAuthHelper::get_logged_in_agent_id());

      $this->vars['services']   = $services_models;
      $this->vars['locations']  = $locations_models;
      $this->vars['agents']     = $agents_models;

      if($services_models){
        if(isset($this->params['service_id'])){
          $selected_service = $services->load_by_id($this->params['service_id']);
        }else{
          $selected_service = $services_models[0];
        }
      }else{
        $selected_service = false;
      }


      if($locations_models){
        // show all locations option if agent can only be present at one place - because it means he does not have overlapping appointments on the calendar
        $default_location_id = OsSettingsHelper::is_on('one_location_at_time') ? false : $locations_models[0]->id;
        $selected_location_id = isset($this->params['location_id']) ? $this->params['location_id'] : $default_location_id;
      }else{
        $selected_location_id = false;
      }

      $this->vars['selected_location'] = $selected_location_id ? new OsLocationModel($selected_location_id) : false;
      $this->vars['selected_location_id'] = $selected_location_id;

      $timeblock_interval = OsSettingsHelper::get_default_timeblock_interval();
      $selected_service_id = ($selected_service) ? $selected_service->id : false;

      $this->vars['selected_service'] = $selected_service;
      $this->vars['selected_service_id'] = $selected_service_id;



			// we are using two separate booking requests because the calendar on top has to generate availability timeline,
	    // which can only be generated if we know service to check for. The second booking request is used to retrieve
	    // shared resources for all services and locations (unless specific location is selected)
			$availability_booking_request = new \LatePoint\Misc\BookingRequest(['start_date' => $target_date->format('Y-m-d')]);
			$general_booking_request = new \LatePoint\Misc\BookingRequest(['start_date' => $target_date->format('Y-m-d')]);
			if($selected_location_id){
				$availability_booking_request->location_id = $selected_location_id;
				$general_booking_request->location_id = $selected_location_id;
			}
			if($selected_service){
				$availability_booking_request->service_id = $selected_service->id;
				// TODO add capacity and duration select box and POST params if multiple durations in a service
				$availability_booking_request->duration = $selected_service->duration;
				$timeblock_interval = $selected_service->get_timeblock_interval();
			}

      if($this->logged_in_agent_id) {
				$availability_booking_request->agent_id = $this->logged_in_agent_id;
				$general_booking_request->agent_id = $this->logged_in_agent_id;
      }

			$resources = OsResourceHelper::get_resources_grouped_by_day($general_booking_request, $target_date, $target_date);
			$availability_resources = OsResourceHelper::get_resources_grouped_by_day($availability_booking_request, $target_date, $target_date);
			$work_boundaries = OsResourceHelper::get_work_boundaries_for_resources($resources[$target_date->format('Y-m-d')]);
			$work_total_minutes = $work_boundaries->end_time - $work_boundaries->start_time;

      $this->vars['timeblock_interval'] = $timeblock_interval;

      $bookings = [];
			$agent_work_time_periods = [];
      if($agents_models){
        foreach($agents_models as $agent){
					$agent_work_time_periods[$agent->id] = [];
          $args = ['agent_id' => $agent->id];
          if($selected_location_id) $args['location_id'] = $selected_location_id;
          $bookings[$agent->id] = OsBookingHelper::get_bookings_for_date($target_date->format('Y-m-d'), $args);
        }
				foreach($availability_resources[$target_date->format('Y-m-d')] as $resource){
					$agent_work_time_periods[$resource->agent_id] = array_merge($agent_work_time_periods[$resource->agent_id], $resource->work_time_periods);
				}
      }


      $this->vars['agent_work_time_periods'] = $agent_work_time_periods;

			$this->vars['availability_booking_request'] = $availability_booking_request;
			$this->vars['general_booking_request'] = $general_booking_request;

			$agents_resources = [];
			foreach ($agents_models as $agent) {
				$agent_booking_request = clone $availability_booking_request;
				$agent_booking_request->agent_id = $agent->id;
				$daily_resources = OsResourceHelper::get_resources_grouped_by_day($agent_booking_request, $target_date);
				$agents_resources['agent_' . $agent->id] = $daily_resources[$target_date->format('Y-m-d')];
			}
			$this->vars['agents_resources'] = $agents_resources;
			$this->vars['timeline_boundaries'] = OsResourceHelper::get_work_boundaries_for_groups_of_resources($agents_resources);

			$this->vars['work_total_minutes'] = $work_total_minutes;
      $this->vars['work_boundaries'] = $work_boundaries;
      $this->vars['show_day_info'] = OsAuthHelper::is_admin_logged_in();
      $this->vars['target_date_obj'] = $target_date;
      $this->vars['target_date'] = $target_date->format('Y-m-d');
      $this->vars['target_date_string'] = OsTimeHelper::get_readable_date($target_date);

			$this->vars['what_to_show'] = isset($this->params['what_to_show']) ? $this->params['what_to_show'] : 'appointments';


      $today_date = new OsWpDateTime('today');

			if($target_date->format('Y-m-d') == $today_date->format('Y-m-d')){
				$time_now = OsTimeHelper::now_datetime_object();
				$time_now_in_minutes = OsTimeHelper::convert_datetime_to_minutes($time_now);
				if(($time_now_in_minutes<=$work_boundaries->end_time && $time_now_in_minutes>=$work_boundaries->start_time)){
					$this->vars['time_now_label'] = $time_now->format(OsTimeHelper::get_time_format());
					// agents row with avatars and margin below - offset that needs to be accounted for when calculating "time now" indicator position
					$this->vars['time_now_indicator_left_offset'] = ($time_now_in_minutes - $work_boundaries->start_time) / $work_total_minutes * 100;
					$this->vars['show_today_indicator'] = true;
				}else{
					$this->vars['show_today_indicator'] = false;
				}
			}else{
				$this->vars['show_today_indicator'] = false;
			}

      $this->set_layout('none');

      $this->format_render(__FUNCTION__);
    }


    public function widget_top_agents(){
      $date_from = isset($this->params['date_from']) ? OsWpDateTime::os_createFromFormat('Y-m-d', $this->params['date_from']) : new OsWpDateTime('-14 days');
      $date_to = isset($this->params['date_to']) ? OsWpDateTime::os_createFromFormat('Y-m-d', $this->params['date_to']) : new OsWpDateTime('now');

      $this->vars['top_agents'] = OsAgentHelper::get_top_agents($date_from->format('Y-m-d'), $date_to->format('Y-m-d'), 3, false);
      $this->vars['date_from'] = $date_from->format('Y-m-d');
      $this->vars['date_to'] = $date_to->format('Y-m-d');
      $this->vars['date_period_string'] = OsTimeHelper::format_date_with_locale(OsSettingsHelper::get_readable_date_format(), $date_from).' - '.OsTimeHelper::format_date_with_locale(OsSettingsHelper::get_readable_date_format(), $date_to);

      $bookings = new OsBookingModel();
      $this->vars['total_bookings'] = $bookings->should_be_approved()->where(['start_date >=' => $date_from->format('Y-m-d'), 'start_date <=' => $date_to->format('Y-m-d')])->count();

      $this->set_layout('none');

      $this->format_render(__FUNCTION__);
    }


  }

endif;