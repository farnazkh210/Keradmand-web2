<?php 

class OsAgentHelper {

  public static function generate_day_schedule_info($filter){
    $today_date = new OsWpDateTime('today');
    $target_date = new OsWpDateTime($filter->date_from); ?>
    <div class="agent-schedule-info">
      <div class="agent-today-info">
        <?php echo ($target_date->format('Y-m-d') == $today_date->format('Y-m-d')) ? __('Today', 'latepoint') : $target_date->format(OsSettingsHelper::get_readable_date_format()); ?>
        <?php 
        $day_work_periods = OsWorkPeriodsHelper::get_work_periods(new \LatePoint\Misc\Filter(['agent_id' => $filter->agent_id, 'date_from' => $target_date->format('Y-m-d')]));
        $is_working_today = ($day_work_periods && count($day_work_periods) > 0 && $day_work_periods[0]->start_time != $day_work_periods[0]->end_time);
         ?>
        <span class="today-status <?php echo ($is_working_today) ? 'is-on-duty' : 'is-off-duty'; ?>"><?php echo ($is_working_today) ? __('On Duty', 'latepoint') : __('Off Duty', 'latepoint'); ?></span>
        <div class="today-schedule">
          <?php if($is_working_today){ ?>
            <?php foreach($day_work_periods as $period){
              echo '<span>' . OsTimeHelper::minutes_to_hours_and_minutes($period->start_time).' - '.OsTimeHelper::minutes_to_hours_and_minutes($period->end_time) . '</span>';
            } ?>
          <?php }else{
            _e('Not Available', 'latepoint');
          } ?>
        </div>
      </div>
      <div class="today-bookings">
        <?php _e('Bookings', 'latepoint'); ?>
        <div class="today-bookings-count"><?php echo OsBookingHelper::count_bookings($filter); ?></div>
      </div>
    </div>
    <?php
  }

  public static function get_full_name($agent){
  	return join(' ', array($agent->first_name, $agent->last_name));
  }


  public static function get_agent_ids_for_service_and_location($service_id = false, $location_id = false, $active_only = true): array{
    $all_agent_ids = OsConnectorHelper::get_connected_object_ids('agent_id', ['service_id' => $service_id, 'location_id' => $location_id]);
    if($active_only){
      $agents = new OsAgentModel();
      $active_agent_ids = $agents->select('id')->should_be_active()->get_results(ARRAY_A);
      if($active_agent_ids){
        $active_agent_ids = array_column($active_agent_ids, 'id');
        $all_agent_ids = array_intersect($active_agent_ids, $all_agent_ids);
      }else{
        $all_agent_ids = [];
      }
    }
    return $all_agent_ids;
  }


  public static function get_agents_list(): array{
    $agents = new OsAgentModel();
    $agents = $agents->get_results_as_models();
    $agents_list = [];
    if($agents){
      foreach($agents as $agent){
        $agents_list[] = ['value' => $agent->id, 'label' => $agent->full_name];
      }
    }
    return $agents_list;
  }

  public static function get_avatar_url($agent){
    $default_avatar = LATEPOINT_DEFAULT_AVATAR_URL;
    return OsImageHelper::get_image_url_by_id($agent->avatar_image_id, 'thumbnail', $default_avatar);
  }

  public static function get_bio_image_url($agent){
    $default_bio_image = LATEPOINT_DEFAULT_AVATAR_URL;
    return OsImageHelper::get_image_url_by_id($agent->bio_image_id, 'large', $default_bio_image);
  }

  public static function get_top_agents($date_from, $date_to, $limit = false, $location_id = false){
    $agents = new OsAgentModel();
    $bookings = new OsBookingModel();

    $bookings->select('count('.LATEPOINT_TABLE_BOOKINGS.'.id) as total_appointments, SUM(end_time - start_time) as total_minutes, SUM(price) as total_price, agent_id')
              ->join(LATEPOINT_TABLE_AGENTS, [LATEPOINT_TABLE_AGENTS.'.id' => 'agent_id'])
              ->where(['start_date >=' => $date_from, 'start_date <=' => $date_to])
              ->group_by('agent_id')
              ->order_by('total_appointments desc')
              ->should_be_approved();
    if($location_id) $bookings->where(['location_id' => $location_id]);
    if($limit) $bookings->set_limit($limit);

    $top_agents = $bookings->get_results();

    for($i=0; $i<count($top_agents); $i++){
      $bookings = new OsBookingModel();

      $bookings->select('count('.LATEPOINT_TABLE_BOOKINGS.'.id) as total_appointments, service_id, bg_color, name')
                                                            ->join(LATEPOINT_TABLE_SERVICES, [LATEPOINT_TABLE_SERVICES.'.id' => 'service_id'])
                                                            ->where(['agent_id' => $top_agents[$i]->agent_id, 'start_date >=' => $date_from, 'start_date <=' => $date_to])
                                                            ->group_by('service_id')
                                                            ->should_be_approved();
      if($location_id) $bookings->where(['location_id' => $location_id]);
      $top_agents[$i]->service_breakdown = $bookings->get_results(ARRAY_A);
    }
    return $top_agents;
  }

  public static function count_agents_on_duty($date, $location_id = false){
    $agents = new OsAgentModel();
    return $agents->count();
  }

  public static function count_agents(){
    $agents = new OsAgentModel();
    return $agents->count();
  }

  public static function count_openings_for_date($agent, $service, $location, $target_date){
    if(!isset($target_date) || !isset($agent) || !isset($service) || !isset($location) || empty($target_date) || empty($agent) || empty($service) || empty($location)) return 0;

    $work_periods = OsWorkPeriodsHelper::get_work_periods(new \LatePoint\Misc\Filter(['date_from' => $target_date, 'service_id' => $service->id, 'agent_id' => $agent->id, 'location_id' => $location->id]));
    list($work_start_minutes, $work_end_minutes) = OsWorkPeriodsHelper::get_work_start_end_time($work_periods);

    $timeblock_interval = $service->get_timeblock_interval();

		$filter = new \LatePoint\Misc\Filter(['date_from' => $target_date, 'agent_id' => $agent->id]);
    $filter->location_id = (OsSettingsHelper::is_on('one_location_at_time')) ? 0 : $location->id;
    $booked_periods = OsBookingHelper::get_booked_periods($filter);

    $openings = 0;
    for($current_minutes = $work_start_minutes; $current_minutes <= $work_end_minutes; $current_minutes+=$timeblock_interval){
      $is_available = true;

			$booking_request = new \LatePoint\Misc\BookingRequest();
			$booking_request->start_time = $current_minutes;
			$booking_request->end_time = $current_minutes + $service->duration;
			$booking_request->duration = $service->duration;
      $booking_request->buffer_before = $service->buffer_before;
      $booking_request->buffer_after = $service->buffer_after;
			$booking_request->service_id = $service->id;

      if(OsBookingHelper::is_timeframe_in_booked_periods($booking_request, $booked_periods, $service)){
        $is_available = false;
      }
      if(!OsWorkPeriodsHelper::is_timeframe_in_work_periods($booking_request, $work_periods)){
        $is_available = false;
      }
      if($is_available) $openings++;
    }
    return $openings;
  }
}