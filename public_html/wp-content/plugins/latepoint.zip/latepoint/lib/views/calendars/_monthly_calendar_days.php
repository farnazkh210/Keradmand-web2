<?php
OsCalendarHelper::generate_single_month($booking_request, $target_date, $calendar_settings);