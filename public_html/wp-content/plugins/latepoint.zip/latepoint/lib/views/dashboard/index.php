
<div class="os-dashboard-row">
	<div class="os-dashboard-column">
		<?php echo $widget_daily_bookings_chart; ?>
	</div>
	<div class="os-dashboard-column os-upcoming">
		<?php echo $widget_upcoming_appointments; ?>
	</div>
</div>
<?php echo $widget_bookings_and_availability_timeline; ?>