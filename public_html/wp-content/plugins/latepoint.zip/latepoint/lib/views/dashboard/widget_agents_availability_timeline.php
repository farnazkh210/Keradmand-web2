<div class="os-widget os-widget-animated" data-os-reload-action="<?php echo OsRouterHelper::build_route_name('dashboard', 'widget_agents_availability_timeline'); ?>">
	<div class="os-widget-header with-actions">
		<h3 class="os-widget-header-text"><?php _e('Availability', 'latepoint'); ?></h3>
		<div class="os-widget-header-actions-trigger"><i class="latepoint-icon latepoint-icon-more-horizontal"></i></div>
		<div class="os-widget-header-actions">
			<?php if(count($locations) > 1){ ?>
				<select name="location_id" id="" class="os-trigger-reload-widget">
					<?php foreach($locations as $location){ ?>
					<option value="<?php echo $location->id ?>" <?php if($location->id == $booking_request->location_id) echo 'selected="selected"' ?>><?php echo $location->name; ?></option>
					<?php } ?>
				</select>
			<?php } ?>
			<?php if(count($services) > 1){ ?>
				<select name="service_id" id="" class="os-trigger-reload-widget">
					<?php foreach($services as $service){ ?>
					<option value="<?php echo $service->id ?>" <?php if($service->id == $booking_request->service_id) echo 'selected="selected"' ?>><?php echo $service->name; ?></option>
					<?php } ?>
				</select>
			<?php } ?>
			<div class="os-date-range-picker" data-single-date="yes">
				<span class="range-picker-value"><?php echo $target_date_string; ?></span>
				<i class="latepoint-icon latepoint-icon-chevron-down"></i>
				<input type="hidden" name="date_from" value="<?php echo $target_date; ?>"/>
				<input type="hidden" name="date_to" value="<?php echo $target_date; ?>"/>
			</div>
		</div>
	</div>
	<div class="os-widget-content">
		<div class="agents-day-availability-timeslots">
			<?php 
			if($connections){
				foreach($agents as $agent){
					$agent_booking_request = clone $booking_request;
					$agent_booking_request->agent_id = $agent->id;
					echo OsTimelineHelper::availability_timeline($agent_booking_request, $timeline_boundaries, $agents_resources['agent_'.$agent->id], ['agent_to_show' => $agent]);
				}
			}else{ ?>
				  <div class="no-results-w">
				    <div class="icon-w"><i class="latepoint-icon latepoint-icon-grid"></i></div>
				    <h2><?php _e('No Agents Created', 'latepoint'); ?></h2>
				    <a href="<?php echo OsRouterHelper::build_link(OsRouterHelper::build_route_name('agents', 'new_form') ) ?>" class="latepoint-btn"><i class="latepoint-icon latepoint-icon-plus-square"></i><span><?php _e('Create Agent', 'latepoint'); ?></span></a>
				  </div>
				<?php 
			} ?>
		</div>
	</div>
</div>