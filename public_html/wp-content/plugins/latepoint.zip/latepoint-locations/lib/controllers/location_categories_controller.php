<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}


if ( ! class_exists( 'OsLocationCategoriesController' ) ) :


  class OsLocationCategoriesController extends OsController {



    function __construct(){
      parent::__construct();

      $this->views_folder = plugin_dir_path( __FILE__ ) . '../views/location_categories/';
      $this->vars['page_header'] = OsMenuHelper::get_menu_items_by_id('locations');
      $this->vars['breadcrumbs'][] = array('label' => __('Location Categories', 'latepoint-locations'), 'link' => OsRouterHelper::build_link(OsRouterHelper::build_route_name('location_categories', 'index') ) );
    }



    /*
      Edit location
    */

    public function edit(){
    }



    /*
      New category form
    */

    public function new_form(){
      $this->vars['page_header'] = __('Create New Location', 'latepoint-locations');
      $this->vars['breadcrumbs'][] = array('label' => __('Create New Location', 'latepoint-locations'), 'link' => false );

      $this->vars['category'] = new OsLocationCategoryModel();

      if($this->get_return_format() == 'json'){
        $response_html = $this->render($this->views_folder.'new_form', 'none');
        echo wp_send_json(array('status' => 'success', 'message' => $response_html));
        exit();
      }else{
        echo $this->render($this->views_folder . 'new_form', $this->get_layout());
      }
    }



    /*
      List of categories for select box
    */

    public function list_for_select(){


      $categories = new OsLocationCategoryModel();
      $categories = $categories->get_results();
      $response_html = '<option value="0">'.__('Not categorized', 'latepoint-locations').'</option>';
      foreach($categories as $category){
        $response_html.= '<option>'.$category->name.'</option>';
      }
      echo wp_send_json(array('status' => 'success', 'message' => $response_html));
    }



    /*
      Index of categories
    */

    public function index(){
      $this->vars['page_header'] = OsMenuHelper::get_menu_items_by_id('locations');
      $location_categories = new OsLocationCategoryModel();
      $location_categories = $location_categories->get_results_as_models();
      $this->vars['location_categories'] = $location_categories;

      $locations = new OsLocationModel();
      $this->vars['uncategorized_locations'] = $locations->where(array('category_id' => ['OR' => [0, 'IS NULL']]))->order_by('order_number asc')->get_results_as_models();

      $this->format_render(__FUNCTION__);
    }



    public function destroy(){
      if(filter_var($this->params['id'], FILTER_VALIDATE_INT)){
        $location_category = new OsLocationCategoryModel($this->params['id']);
        if($location_category->delete()){
          $status = LATEPOINT_STATUS_SUCCESS;
          $response_html = __('Location Category Removed', 'latepoint-locations');
        }else{
          $status = LATEPOINT_STATUS_ERROR;
          $response_html = __('Error Removing Location Category. Error: FJI8321', 'latepoint-locations');
        }
      }else{
        $status = LATEPOINT_STATUS_ERROR;
        $response_html = __('Error Removing Location Category. Error: SIF2348', 'latepoint-locations');
      }

      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => $status, 'message' => $response_html));
      }
    }



    public function udpate_order_of_categories(){
      foreach($this->params['item_datas'] as $location_data){
        $location = new OsLocationModel($location_data['id']);
        $location->category_id = $location_data['category_id'];
        $location->order_number = $location_data['order_number'];
        if($location->save()){
          $response_html = __('Location Order Updated', 'latepoint-locations');
          $status = LATEPOINT_STATUS_SUCCESS;
        }else{
          $response_html = $location->get_error_messages();
          $status = LATEPOINT_STATUS_ERROR;
          break;
        }
      }
      if($status == LATEPOINT_STATUS_SUCCESS && is_array($this->params['category_datas'])){
        foreach($this->params['category_datas'] as $category_data){
          $location_category = new OsLocationCategoryModel($category_data['id']);
          $location_category->order_number = $category_data['order_number'];
          $location_category->parent_id = ($category_data['parent_id']) ? $category_data['parent_id'] : NULL;
          if($location_category->save()){
            $response_html = __('Location Categories Order Updated', 'latepoint-locations');
            $status = LATEPOINT_STATUS_SUCCESS;
          }else{
            $response_html = $location_category->get_error_messages();
            $status = LATEPOINT_STATUS_ERROR;
            break;
          }
        }
      }
      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => $status, 'message' => $response_html));
      }
    }


    /*
      Create location
    */

    public function create(){
      $location_category = new OsLocationCategoryModel();
      $location_category->set_data($this->params['location_category']);
      if($location_category->save()){
        $response_html = __('Location Category Created.', 'latepoint-locations');
        $status = LATEPOINT_STATUS_SUCCESS;
      }else{
        $response_html = $location_category->get_error_messages();
        $status = LATEPOINT_STATUS_ERROR;
      }
      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => $status, 'message' => $response_html));
      }
    }


    /*
      Update location category
    */

    public function update(){
      $location_category = new OsLocationCategoryModel($this->params['location_category']['id']);
      $location_category->set_data($this->params['location_category']);
      if($location_category->save()){
        $response_html = __('Location Category Updated. ID: ', 'latepoint-locations') . $location_category->id;
        $status = LATEPOINT_STATUS_SUCCESS;
      }else{
        $response_html = $location_category->get_error_messages();
        $status = LATEPOINT_STATUS_ERROR;
      }
      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => $status, 'message' => $response_html));
      }
    }



  }


endif;