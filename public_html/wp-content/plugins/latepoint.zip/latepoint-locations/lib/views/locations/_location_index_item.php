<div class="os-location os-location-status-active">
  <div class="os-location-body">
    <div class="os-location-address">
      <?php if($location->full_address){ ?>
        <iframe width="100%" height="240" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.it/maps?q=<?php echo urlencode($location->full_address); ?>&output=embed"></iframe>
      <?php } ?>
    </div>

    <div class="os-location-header">
      <h3 class="location-name"><?php echo $location->name; ?></h3>
      <div class="os-location-info"><?php echo $location->full_address; ?></div>
      <a href="<?php echo OsRouterHelper::build_link(OsRouterHelper::build_route_name('locations', 'edit_form'), ['id' => $location->id] ); ?>" class="edit-location-btn">
        <i class="latepoint-icon latepoint-icon-edit-3"></i>
        <span><?php _e('Edit', 'latepoint-locations'); ?></span>
      </a>
    </div>
    <div class="os-location-agents">
      <div class="label"><?php _e('Agents:', 'latepoint-locations'); ?></div>
      <?php if($location->connected_agents){ ?>
        <div class="agents-avatars">
        <?php foreach($location->connected_agents as $agent){ ?>
          <div class="agent-avatar" style="background-image: url(<?php echo $agent->avatar_url; ?>)"></div>
        <?php } ?>
        </div>
      <?php }else{
        echo '<a href="'.OsRouterHelper::build_link(OsRouterHelper::build_route_name('locations', 'edit_form'), ['id' => $location->id] ).'" class="no-agents-for-location">'.__('No Agents Assigned', 'latepoint-locations').'</a>';
      } ?>
    </div>
  </div>
</div>