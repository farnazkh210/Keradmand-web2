<div class="os-form-w">
	<?php $action = ($location_category->is_new_record()) ? 'create' : 'update'; ?>
  <form data-os-action="<?php echo OsRouterHelper::build_route_name('location_categories', $action); ?>" action="" <?php if($location_category->is_new_record()) echo ' data-os-success-action="reload"'; ?>>
  	<div class="os-row">
  		<div class="os-col-lg-6">
				<?php echo OsFormHelper::text_field('location_category[name]', __('Category Name', 'latepoint-locations'), $location_category->name); ?>
      </div>
      <div class="os-col-lg-6">
        <?php echo OsFormHelper::textarea_field('location_category[short_description]', __('Short Description', 'latepoint-locations'), $location_category->short_description, ['rows' => 1]); ?>
  		</div>
  		<div class="os-col-lg-12">
  			<div class="os-form-group">
	        <?php echo OsFormHelper::media_uploader_field('location_category[selection_image_id]', 0, __('Category Image', 'latepoint-locations'), __('Remove Image', 'latepoint-locations'), $location_category->selection_image_id); ?>
	      </div>
  		</div>
  	</div>
    <?php if(!$location_category->is_new_record()) echo OsFormHelper::hidden_field('location_category[id]', $location_category->id); ?>
    <div class="os-form-buttons os-flex">
      <?php echo OsFormHelper::button('submit', __('Save Category', 'latepoint-locations'), 'submit', ['class' => 'latepoint-btn']);  ?>
      <?php
      if($location_category->is_new_record()){
	      echo '<a href="#" class="latepoint-btn latepoint-btn-secondary add-location-category-trigger">'. __('Cancel', 'latepoint-locations').'</a>';
      }else{
	      echo '<a href="#" class="latepoint-btn latepoint-btn-danger" style="margin-left: auto;" 
				        data-os-prompt="'.__('Are you sure you want to remove this category?', 'latepoint-locations').'" 
				        data-os-params="'. OsUtilHelper::build_os_params(['id' => $location_category->id]). '" 
				        data-os-success-action="reload" 
				        data-os-action="'.OsRouterHelper::build_route_name('location_categories', 'destroy').'">'.__('Delete Category', 'latepoint-locations').'</a>'; 
      } ?>
    </div>
	</form>
</div>