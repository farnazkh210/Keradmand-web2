<?php
/**
 * Plugin Name: LatePoint Addon - Locations
 * Plugin URI:  https://latepoint.com/
 * Description: LatePoint addon for locations
 * Version:     1.0.7
 * Author:      LatePoint
 * Author URI:  https://latepoint.com/
 * Text Domain: latepoint-locations
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}

// If no LatePoint class exists - exit, because LatePoint plugin is required for this addon

if ( ! class_exists( 'LatePointAddonLocations' ) ) :

/**
 * Main Addon Class.
 *
 */

class LatePointAddonLocations {

  /**
   * Addon version.
   *
   */
  public $version = '1.0.7';
  public $db_version = '1.0.1';
  public $addon_name = 'latepoint-locations';




  /**
   * LatePoint Constructor.
   */
  public function __construct() {
    $this->define_constants();
    $this->init_hooks();
  }

  /**
   * Define LatePoint Constants.
   */
  public function define_constants() {
    $this->define( 'LATEPOINT_ADDON_LOCATIONS_ABSPATH', dirname( __FILE__ ) . '/' );
    $this->define( 'LATEPOINT_ADDON_LOCATIONS_LIB_ABSPATH', LATEPOINT_ADDON_LOCATIONS_ABSPATH . 'lib/' );
    $this->define( 'LATEPOINT_ADDON_LOCATIONS_VIEWS_ABSPATH', LATEPOINT_ADDON_LOCATIONS_LIB_ABSPATH . 'views/' );
  }


  public static function public_stylesheets() {
    return plugin_dir_url( __FILE__ ) . 'public/stylesheets/';
  }

  /**
   * Define constant if not already set.
   *
   */
  public function define( $name, $value ) {
    if ( ! defined( $name ) ) {
      define( $name, $value );
    }
  }

  /**
   * Include required core files used in admin and on the frontend.
   */
  public function includes() {

    // CONTROLLERS
    include_once( dirname( __FILE__ ) . '/lib/controllers/locations_controller.php' );
    include_once( dirname( __FILE__ ) . '/lib/controllers/location_categories_controller.php' );

    // HELPERS

    // MODELS

  }

  public function init_hooks(){
    add_action('latepoint_includes', [$this, 'includes']);

    add_action( 'init', array( $this, 'init' ), 0 );

    add_action('latepoint_wp_enqueue_scripts', [$this, 'load_front_scripts_and_styles']);
    add_action('latepoint_admin_enqueue_scripts', [$this, 'load_admin_scripts_and_styles']);

    add_action( 'latepoint_settings_steps_after', array( $this, 'add_location_categories_setting' ) );
    add_action( 'latepoint_locations_index', [$this, 'output_locations_index'] );

    add_action('latepoint_step_verify_appointment_info',[$this, 'add_location_information']);
    add_action('latepoint_step_confirmation_appointment_info',[$this, 'add_location_information']);


    add_filter('latepoint_side_menu', [$this, 'add_menu_links']);
    add_filter('latepoint_installed_addons', [$this, 'register_addon']);
    add_filter('latepoint_locations_addon_installed', [$this, 'show_locations']);
    add_filter('latepoint_custom_field_condition_properties', [$this, 'add_custom_field_condition_properties']);
    add_filter('latepoint_available_values_for_condition_property', [$this, 'add_values_for_condition_property'], 10, 2);
    add_filter('latepoint_model_options_for_multi_select', [$this, 'add_options_for_multi_select'], 10, 2);

    add_filter('latepoint_bookings_data_for_csv_export', [$this, 'add_location_to_bookings_data_for_csv'], 11, 2);
    add_filter('latepoint_booking_row_for_csv_export', [$this, 'add_location_to_booking_row_for_csv'], 11, 3);

    register_activation_hook(__FILE__, [$this, 'on_activate']);
    register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);


  }

  /**
   * Init LatePoint when WordPress Initialises.
   */
  public function init() {
    // Set up localisation.
    $this->load_plugin_textdomain();
  }



  public function add_menu_links($menus){
    if(!OsAuthHelper::is_admin_logged_in()) return $menus;
    for($i=0; $i<count($menus); $i++){
      if(isset($menus[$i]['id']) && $menus[$i]['id'] == 'locations'){
        $menus[$i] = [ 'id' => 'locations', 'label' => __( 'Locations', 'latepoint' ), 'icon' => 'latepoint-icon latepoint-icon-map-pin', 'link' => OsRouterHelper::build_link(['locations', 'index']),
          'children' => [
                          ['label' => __( 'All Locations', 'latepoint' ), 'icon' => '', 'link' => OsRouterHelper::build_link(['locations', 'index'])],
                          ['label' => __( 'Categories', 'latepoint' ), 'icon' => '', 'link' => OsRouterHelper::build_link(['location_categories', 'index'])],
        ]];
      }
    }
    return $menus;
  }

  public function add_options_for_multi_select($options, $property){
    if($property == 'location' || $property == 'OsLocationModel'){
      $location = new OsLocationModel;
      $locations = $location->get_results_as_models();
      if($locations){
        foreach($locations as $location){
          $options[] = ['id' => $location->id, 'name' => $location->name];
        }
      }
    }
    return $options;
  }

  public function add_values_for_condition_property($values, $property){
    if($property == 'location'){
      $values = OsFormHelper::model_options_for_multi_select('location');
    }
    return $values;
  }


  public function add_custom_field_condition_properties($properties){
    $properties['location'] = __('Location', 'latepoint-locations');
    return $properties;
  }

  public function add_location_information($booking){
    if($booking->location_id){
      if(!empty($booking->location->full_address)){
        echo '<li>'.__('Location:', 'latepoint-locations').'<strong>'.$booking->location->full_address.'</strong></li>';
      }else{
        // if only 1 location - don't show the name
        $locations = new OsLocationModel();
        $location_ids = $locations->select('id')->should_be_active()->get_results(ARRAY_A);
        if(is_array($location_ids) && count($location_ids) > 1){
          echo '<li>'.__('Location:', 'latepoint-locations').'<strong>'.$booking->location->name.'</strong></li>';
        }
      }
    }
  }

  public function add_location_to_booking_row_for_csv($booking_row, $booking, $params = []){
    $booking_row[] = $booking->location->name;
    return $booking_row;
  }


  public function add_location_to_bookings_data_for_csv($bookings_data, $params = []){
    $bookings_data[0][] = __('Location', 'latepoint-locations');
    return $bookings_data;
  }



  public function add_location_categories_setting(){
    echo OsFormHelper::toggler_field('settings[steps_show_location_categories]', __('Show location categories', 'latepoint-locations'), OsSettingsHelper::is_on('steps_show_location_categories'));
  }

  public function output_locations_index(){
    $locations = new OsLocationModel();
    $locations = $locations->get_results_as_models();
    ?>
    <div class="os-locations-list">
      <?php 
      if($locations){
        foreach($locations as $location){ ?>
          <div class="os-location os-location-status-active">
            <div class="os-location-body">
              <div class="os-location-address">
                <?php if($location->full_address){ ?>
                  <iframe width="100%" height="240" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.it/maps?q=<?php echo urlencode($location->full_address); ?>&output=embed"></iframe>
                <?php } ?>
              </div>

              <div class="os-location-header">
                <h3 class="location-name"><?php echo $location->name; ?></h3>
                <div class="os-location-info"><?php echo $location->full_address; ?></div>
                <a href="<?php echo OsRouterHelper::build_link(OsRouterHelper::build_route_name('locations', 'edit_form'), ['id' => $location->id] ); ?>" class="edit-location-btn">
                  <i class="latepoint-icon latepoint-icon-edit-3"></i>
                  <span><?php _e('Edit', 'latepoint-locations'); ?></span>
                </a>
              </div>
              <div class="os-location-agents">
                <div class="label"><?php _e('Agents:', 'latepoint-locations'); ?></div>
                <?php if($location->connected_agents){ ?>
                  <div class="agents-avatars">
                  <?php foreach($location->connected_agents as $agent){ ?>
                    <div class="agent-avatar" style="background-image: url(<?php echo $agent->avatar_url; ?>)"></div>
                  <?php } ?>
                  </div>
                <?php }else{
                  echo '<a href="'.OsRouterHelper::build_link(OsRouterHelper::build_route_name('locations', 'edit_form'), ['id' => $location->id] ).'" class="no-agents-for-location">'.__('No Agents Assigned', 'latepoint-locations').'</a>';
                } ?>
              </div>
            </div>
          </div><?php 
        }
      } ?>
      <a class="create-location-link-w" href="<?php echo OsRouterHelper::build_link(OsRouterHelper::build_route_name('locations', 'new_form') ) ?>">
        <div class="create-location-link-i">
          <div class="add-location-graphic-w">
            <div class="add-location-plus"><i class="latepoint-icon latepoint-icon-plus4"></i></div>
          </div>
          <div class="add-location-label"><?php _e('Add Location', 'latepoint-locations'); ?></div>
        </div>
      </a>
    </div>
    <?php
  }


  public function show_locations($show_locations){
    return true;
  }


  public function load_plugin_textdomain() {
    load_plugin_textdomain('latepoint-locations', false, dirname(plugin_basename(__FILE__)) . '/languages');
  }

  public function on_deactivate(){
  }

  public function on_activate(){
    if(class_exists('OsDatabaseHelper')) OsDatabaseHelper::check_db_version_for_addons();
    do_action('latepoint_on_addon_activate', $this->addon_name, $this->version);
  }

  public function register_addon($installed_addons){
    $installed_addons[] = ['name' => $this->addon_name, 'db_version' => $this->db_version, 'version' => $this->version];
    return $installed_addons;
  }


  public function load_front_scripts_and_styles(){
    // Stylesheets

    // Javascripts

  }

  public function load_admin_scripts_and_styles($localized_vars){

    // Stylesheets
    wp_enqueue_style( 'latepoint-locations-admin', $this->public_stylesheets() . 'latepoint-locations-admin.css', false, $this->version );

    // Javascripts

  }




}

endif;
if ( in_array( 'latepoint/latepoint.php', get_option( 'active_plugins', array() ) )  || array_key_exists('latepoint/latepoint.php', get_site_option('active_sitewide_plugins', array())) ) {
	$LATEPOINT_ADDON_LOCATIONS = new LatePointAddonLocations();
}
$latepoint_session_salt = 'ZjYwNTU0MzgtNDAwNC00OTgzLTgzMTUtNWZmNDlkNmUwNjUy';
