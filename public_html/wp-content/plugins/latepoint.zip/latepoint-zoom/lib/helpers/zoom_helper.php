<?php 
class OsZoomHelper {

	public static function is_zoom_enabled_for_service($service_id){
		return (OsMetaHelper::get_service_meta_by_key('enable_zoom', $service_id) == 'on');
	}

	public static function get_topic_template(){
		return OsSettingsHelper::get_settings_value('zoom_meeting_topic_template', '{service_name}');
	}

	public static function generate_meeting_password(){
		return OsUtilHelper::random_text('nozero', 5);
	}


	public static function get_zoom_user_id_for_agent_id($agent_id){
		return OsMetaHelper::get_agent_meta_by_key('zoom_user_id', $agent_id);
	}

	public static function delete_meeting_for_booking_id($booking_id){
		$meeting_id = self::get_zoom_meeting_id_for_booking_id($booking_id);
		if($meeting_id){
			$zoom = self::get_zoom();
			$response = $zoom->doRequest('DELETE','/meetings/'.$meeting_id);
			if ($response === false) {
				error_log("LatePoint Zoom Connect Errors:".implode("\n",$zoom->requestErrors()));
			} else {
				if($zoom->responseCode() == 204){
					// meeting updated
				}else{
					error_log("LatePoint Zoom Connect Errors:".$zoom->responseCode());
					error_log("LatePoint Zoom Connect Errors:".print_r($response, true));
				}
			} 
		}
	}

	public static function update_or_create_meeting_for_booking($booking){
		$meeting_id = self::get_zoom_meeting_id_for_booking_id($booking->id);
		if($meeting_id){
			$zoom = self::get_zoom();

	    $topic = self::get_topic_template();
	    $topic = OsReplacerHelper::replace_all_vars($topic, array('customer' => $booking->customer, 'agent' => $booking->agent, 'booking' => $booking));

			$response = $zoom->doRequest('PATCH','/meetings/'.$meeting_id, [], [], [ 	'topic'=> $topic, 
																																				'type' => 2,
																																				'start_time' => $booking->format_start_date_and_time('Y-m-d\TH:i:s'),
																																				'timezone' => OsTimeHelper::get_wp_timezone_name(),
																																				'duration' => $booking->get_total_duration()]);
			if ($response === false) {
				error_log("LatePoint Zoom Connect Errors:".implode("\n",$zoom->requestErrors()));
			} else {
				if($zoom->responseCode() == 204){
					// meeting updated
				}else{
					error_log("LatePoint Zoom Connect Errors:".$zoom->responseCode());
					error_log("LatePoint Zoom Connect Errors:".print_r($response, true));
				}
			}
		}else{
			self::create_meeting($booking);
		}
	}

	public static function get_zoom_meeting_id_for_booking_id($booking_id){
		return OsMetaHelper::get_booking_meta_by_key('zoom_meeting_id', $booking_id);
	}

	public static function get_zoom_meeting_url_for_booking_id($booking_id){
		return OsMetaHelper::get_booking_meta_by_key('zoom_meeting_join_url', $booking_id);
	}

	public static function get_zoom_meeting_password_for_booking_id($booking_id){
		return OsMetaHelper::get_booking_meta_by_key('zoom_meeting_password', $booking_id);
	}

	public static function get_zoom(){
		$zoom = new LatepointZoomApi( OsSettingsHelper::get_settings_value('zoom_api_key'), OsSettingsHelper::get_settings_value('zoom_api_secret') );
		return $zoom;
	}

	public static function create_meeting($booking){
		$zoom = self::get_zoom();
		$zoom_user_id = self::get_zoom_user_id_for_agent_id($booking->agent_id);
		if(!$zoom_user_id) return false;
		$meeting_password = self::generate_meeting_password();

    $topic = self::get_topic_template();
    $topic = OsReplacerHelper::replace_booking_vars($topic, $booking);
    $topic = OsReplacerHelper::replace_customer_vars($topic, $booking->customer);

		$response = $zoom->doRequest('POST',"/users/${zoom_user_id}/meetings", [], [], [ 	'topic'=> $topic, 
																																											'type' => 2,
																																											'start_time' => $booking->format_start_date_and_time('Y-m-d\TH:i:s'),
																																											'timezone' => OsTimeHelper::get_wp_timezone_name(),
																																											'duration' => $booking->get_total_duration(),
																																											'password' => $meeting_password  ]);
		if ($response === false) {
			error_log("LatePoint Zoom Connect Errors:".implode("\n",$zoom->requestErrors()));
		} else {
			if($zoom->responseCode() == 201){
				if($response['join_url'] && $response['id']){
					OsMetaHelper::save_booking_meta_by_key('zoom_meeting_password', $meeting_password, $booking->id);
					OsMetaHelper::save_booking_meta_by_key('zoom_meeting_join_url', $response['join_url'], $booking->id);
					OsMetaHelper::save_booking_meta_by_key('zoom_meeting_id', $response['id'], $booking->id);
				}
			}else{
				error_log("LatePoint Zoom Connect Errors:".$zoom->responseCode());
				error_log("LatePoint Zoom Connect Errors:".print_r($response, true));
			}
		}
	}

	public static function get_list_of_zoom_users(){
		$zoom = self::get_zoom();
		$response = $zoom->doRequest('GET','/users',array('status'=>'active'));

		$users_for_select = [['value' => '', 'label' => __('Not Connected', 'latepoint-zoom')]];
		if ($response === false) {
			error_log("LatePoint Zoom Connect Errors:".implode("\n",$zoom->requestErrors()));
		} else {
			if($zoom->responseCode() == 200){
				$users_arr = $response['users'];
				foreach($users_arr as $zoom_user){
					$users_for_select[] = ['value' => $zoom_user['id'], 'label' => implode(' ', [$zoom_user['first_name'], $zoom_user['last_name']]).' ('.$zoom_user['email'].')'];
				}
			}else{
				error_log("LatePoint Zoom Connect Errors:".$zoom->responseCode());
			}
		}
		return $users_for_select;
	}

	public static function is_enabled(){
		return OsSettingsHelper::is_on('enable_zoom');
	}
}