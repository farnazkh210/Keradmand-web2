<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}


if ( ! class_exists( 'OsZoomController' ) ) :


  class OsZoomController extends OsController {



    function __construct(){
      parent::__construct();

      $this->views_folder = plugin_dir_path( __FILE__ ) . '../views/zoom/';
      $this->vars['breadcrumbs'][] = ['label' => __('Zoom Settings', 'latepoint-zoom'), 'link' => OsRouterHelper::build_link(['zoom', 'for_booking'] )];
    }

    public function settings(){
      $this->vars['page_header'] = OsMenuHelper::get_menu_items_by_id('settings');
      $this->vars['breadcrumbs'][] = array('label' => __('Zoom Settings', 'latepoint-zoom'), 'link' => false );

      $this->format_render(__FUNCTION__);

    }


  }

endif;