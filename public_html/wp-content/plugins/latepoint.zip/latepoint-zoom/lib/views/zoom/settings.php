<div class="latepoint-settings-w os-form-w">
  <form action="" data-os-action="<?php echo OsRouterHelper::build_route_name('settings', 'update'); ?>">
  	<div class="os-payment-processors-w">
	  	<div class="os-payment-processor-w">
	      <div class="os-payment-processor-head">
	        <div class="os-toggler-w">
	          <?php echo OsFormHelper::toggler_field('settings[enable_zoom]', false, OsZoomHelper::is_enabled(), 'toggleZoomSettings', 'large'); ?>
	        </div>
	        <img class="os-processor-logo-img" src="<?php echo esc_attr(LatePointAddonZoom::images_url().'zoom-logo-small.png'); ?>"/>
          <div class="os-processor-name"><?php _e('Enable Zoom Meetings', 'latepoint-zoom') ?></div>
	      </div>
	      <div class="os-payment-processor-body" style="<?php echo OsZoomHelper::is_enabled() ? '' : 'display: none'; ?>" id="toggleZoomSettings">
	      	<div class="os-form-sub-header"><h3><?php _e('API Credentials', 'latepoint-zoom'); ?></h3></div>
					<div class="os-row">
					  <div class="os-col-6">
					    <?php echo OsFormHelper::text_field('settings[zoom_api_key]', __('API Key', 'latepoint-zoom'), OsSettingsHelper::get_settings_value('zoom_api_key')); ?>
					  </div>
					  <div class="os-col-6">
					    <?php echo OsFormHelper::password_field('settings[zoom_api_secret]', __('API Secret', 'latepoint-zoom'), OsSettingsHelper::get_settings_value('zoom_api_secret')); ?>
					  </div>
				  </div>
          <div class="os-form-sub-header"><h3><?php _e('Other Settings', 'latepoint'); ?></h3></div>
          <div class="latepoint-message latepoint-message-subtle"><?php _e('You can use variables in these templates, they will be replaced with a value for the booking. ', 'latepoint-zoom') ?><?php echo OsUtilHelper::template_variables_link_html(); ?></div>
          <div class="os-row">
            <div class="os-col-12">
              <?php echo OsFormHelper::text_field('settings[zoom_meeting_topic_template]', __('Template For Meeting Topic', 'latepoint'), OsZoomHelper::get_topic_template()); ?>
            </div>
          </div>
	      </div>
	    </div>
    </div>
    <?php echo OsFormHelper::button('submit', __('Save Settings', 'latepoint'), 'submit', ['class' => 'latepoint-btn latepoint-btn-md'], 'latepoint-icon-checkmark'); ?>
  </form>
</div>