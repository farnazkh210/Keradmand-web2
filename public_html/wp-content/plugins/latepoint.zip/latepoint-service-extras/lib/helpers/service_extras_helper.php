<?php 

class OsServiceExtrasHelper {

  public static function should_step_be_skipped($skip, $step_name, $booking_object){
    if($step_name == 'service_extras'){
      $service_extras = new OsServiceExtraModel();
      if($booking_object->service_id){
        // show only extras attached to a selected service
        $connected_ids = OsServiceExtrasConnectorHelper::get_connected_extras_ids_to_service($booking_object->service_id);
        if(empty($connected_ids)){
          // selected service has no connected service extras - skip the step
          $skip = true;
          return $skip;
        }
        $service_extras->where(['id' => $connected_ids]);
      }
      $total_service_extras = $service_extras->should_be_active()->count();
      if($total_service_extras == 0) $skip = true;
    }
    return $skip;
  }

  public static function save_service_extras_for_booking($booking_id, $service_extras_ids = []){
    $clean_service_extras = self::extract_service_extras_ids_and_quantity($service_extras_ids);

    // Remove not existing extras
    $existing_service_extras_ids = self::get_service_extras_ids_for_booking_id($booking_id);
    $ids_to_remove = array_diff($existing_service_extras_ids, array_keys($clean_service_extras));
    self::remove_service_extras_from_booking($booking_id, $ids_to_remove);

    // Add new extras
    $ids_to_save = array_diff(array_keys($clean_service_extras), $existing_service_extras_ids);
    if(!empty($ids_to_save)){
      foreach($ids_to_save as $service_extra_id){
        $service_extra = new OsServiceExtraModel($service_extra_id);
        if($service_extra){
          $booking_service_extra = new OsBookingServiceExtraModel();
          $booking_service_extra->booking_id = $booking_id;
          $booking_service_extra->service_extra_id = $service_extra_id;
          $booking_service_extra->price = $service_extra->charge_amount;
          $booking_service_extra->duration = $service_extra->duration;
          $booking_service_extra->quantity = $clean_service_extras[$service_extra_id] ? $clean_service_extras[$service_extra_id] : 1;
          $booking_service_extra->save();
        }
      }
    }

    // Update quantity of existing ones
    $ids_to_update = array_intersect(array_keys($clean_service_extras), $existing_service_extras_ids);
    if(!empty($ids_to_update)){
      foreach($ids_to_update as $id_to_update){
        $booking_service_extra = new OsBookingServiceExtraModel();
        $items_to_update = $booking_service_extra->where(['booking_id' => $booking_id, 'service_extra_id' => $id_to_update])->get_results_as_models();
        if($items_to_update){
          foreach($items_to_update as $item_to_update){
            $item_to_update->update_attributes(['quantity' => $clean_service_extras[$id_to_update]]);
          }
        }
      }
    }
  }

  public static function remove_service_extras_from_booking($booking_id, $service_extras_ids_to_remove){
    if(empty($service_extras_ids_to_remove)) return;
    $booking_service_extra = new OsBookingServiceExtraModel();
    $items_to_delete = $booking_service_extra->where(['booking_id' => $booking_id, 'service_extra_id' => $service_extras_ids_to_remove])->get_results_as_models();
    if($items_to_delete){
      foreach($items_to_delete as $item_to_delete){
        $item_to_delete->delete();
      }
    }
  }

  public static function get_service_extras_info_for_booking_id($booking_id){
    $booking_service_extra = new OsBookingServiceExtraModel();
    $booking_service_extras = $booking_service_extra->select('service_extra_id as id, duration, quantity, price')->where(['booking_id' => $booking_id])->get_results(ARRAY_A);
    $formatted_service_extras = [];
    if(!empty($booking_service_extras)){
      foreach($booking_service_extras as $extra){
        $formatted_service_extras[$extra['id']] = $extra;
      }
    }
    return $formatted_service_extras;
  }

  public static function format_service_extras_to_string($booking_service_extras){
    $booking_service_extras_ids = [];
    if($booking_service_extras){
      foreach($booking_service_extras as $service_extra){
        $booking_service_extras_ids[] = $service_extra['id'].':'.$service_extra['quantity'];
      }
    }
    return implode(',', $booking_service_extras_ids);
  }

  public static function get_service_extras_ids_for_booking_id($booking_id){
    $booking_service_extra = new OsBookingServiceExtraModel();
    $booking_service_extras = $booking_service_extra->select('service_extra_id')->where(['booking_id' => $booking_id])->get_results();
    $booking_service_extras_ids = [];
    if($booking_service_extras){
      foreach ($booking_service_extras as $service_extra) {
        $booking_service_extras_ids[] = $service_extra->service_extra_id;
      }
    }
    return $booking_service_extras_ids;
  }

  public static function calculate_service_extras_prices($amount, $booking, $apply_coupons){
    if(!empty($booking->service_extras_ids)){
      $clean_service_extras = self::extract_service_extras_ids_and_quantity($booking->service_extras_ids);
      $service_extras = new OsServiceExtraModel();
      $service_extras = $service_extras->where(['id' => array_keys($clean_service_extras)])->get_results_as_models();
      foreach($service_extras as $service_extra){
        $service_extra_price = $service_extra->charge_amount * $clean_service_extras[$service_extra->id];
        $service_extra_price = apply_filters('latepoint_full_amount_for_service_extra', $service_extra_price, $booking, $service_extra, $apply_coupons);
        $amount = $amount + $service_extra_price;
      }
    }
    return $amount;
  }

  public static function extract_service_extras_ids_and_quantity($service_extras_ids = []){
    $service_extras_ids = (is_array($service_extras_ids)) ? $service_extras_ids : explode(',', $service_extras_ids);
    $clean_service_extras = [];
    if(is_array($service_extras_ids)){
      foreach($service_extras_ids as $service_extra_id){
        list($id, $quantity) = array_pad(explode(':', $service_extra_id), 2, 1);
        if(is_numeric($id) && is_numeric($quantity)){
          $clean_service_extras[$id] = $quantity;
        }
      }
    }
    return $clean_service_extras;
  }
}