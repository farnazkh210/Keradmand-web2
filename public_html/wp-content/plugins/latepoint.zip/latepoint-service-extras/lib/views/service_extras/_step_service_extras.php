<div class="step-service-extras-w latepoint-step-content" data-step-name="service_extras" data-clear-action="clear_step_service_extras">
  <?php
    if(!empty($service_extras) && is_array($service_extras)){ ?>
      <div class="os-service-extras os-animated-parent os-items os-selectable-items os-as-rows">
        <?php foreach($service_extras as $service_extra){ ?>
          <div data-max-quantity="<?php echo $service_extra->maximum_quantity; ?>" class="os-item <?php echo OsUtilHelper::is_on($service_extra->multiplied_by_attendies) ? '' : 'not-multiplied-by-attendies'; ?> <?php echo ($service_extra->maximum_quantity > 1) ? 'has-quantity' : ''; ?> os-selectable-item os-priced-item os-allow-multiselect os-animated-child <?php if($booking->service_extras_ids && in_array($service_extra->id, explode(',', $booking->service_extras_ids))) echo 'selected'; ?> <?php if($service_extra->short_description) echo 'with-description'; ?>" 
            data-summary-field-name="service-extras" 
            data-summary-value="<?php echo esc_attr($service_extra->name); ?>" 
            data-item-price="<?php echo $service_extra->charge_amount; ?>" 
            data-priced-item-type="service_extras" 
            data-id-holder=".latepoint_service_extras_ids" 
            data-item-id="<?php echo $service_extra->id; ?>">
            <div class="os-service-extra-selector os-animated-self os-item-i">
              <?php if($service_extra->selection_image_id){ ?>
                <div class="os-item-img-w" style="background-image: url(<?php echo $service_extra->selection_image_url; ?>);"></div>
              <?php } ?>
              <div class="os-item-name-w">
                <div class="os-item-name"><?php echo $service_extra->name; ?></div>
                <?php if($service_extra->short_description){ ?>
                  <div class="os-item-desc"><?php echo $service_extra->short_description; ?></div>
                <?php } ?>
              </div>
              <?php if($service_extra->charge_amount > 0){ ?>
                <div class="os-item-price-w">
                  <div class="os-item-price">
                    <?php echo $service_extra->get_formatted_charge_amount(); ?>
                  </div>
                </div>
              <?php } ?>
              <?php if($service_extra->maximum_quantity > 1){ ?>
              <div class="item-quantity-selector-w">
                <div class="item-quantity-selector item-quantity-selector-minus" data-sign="minus"></div>
                <input type="text" name="" class="item-quantity-selector-input" value="0" placeholder="<?php _e('Qty', 'latepoint-service-extras'); ?>">
                <div class="item-quantity-selector item-quantity-selector-plus" data-sign="plus"></div>
              </div> 
              <?php 
              } ?>
            </div>
          </div>
        <?php } ?>
      </div>
    <?php } ?>
    <?php echo OsFormHelper::hidden_field('booking[service_extras_ids]', '', [ 'class' => 'latepoint_service_extras_ids', 'skip_id' => true]); ?>
</div>