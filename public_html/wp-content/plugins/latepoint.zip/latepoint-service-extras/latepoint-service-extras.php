<?php
/**
 * Plugin Name: LatePoint Addon - Service Extras
 * Plugin URI:  https://latepoint.com/
 * Description: LatePoint addon for service extras
 * Version:     1.0.9
 * Author:      LatePoint
 * Author URI:  https://latepoint.com/
 * Text Domain: latepoint-service-extras
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}

// If no LatePoint class exists - exit, because LatePoint plugin is required for this addon

if ( ! class_exists( 'LatePointAddonServiceExtras' ) ) :

/**
 * Main Addon Class.
 *
 */

class LatePointAddonServiceExtras {

  /**
   * Addon version.
   *
   */
  public $version = '1.0.9';
  public $db_version = '1.0.2';
  public $addon_name = 'latepoint-service-extras';




  /**
   * LatePoint Constructor.
   */
  public function __construct() {
    $this->define_constants();
    $this->init_hooks();
  }

  /**
   * Define LatePoint Constants.
   */
  public function define_constants() {
    $upload_dir = wp_upload_dir();

    global $wpdb;
    $this->define( 'LATEPOINT_SERVICE_EXTRA_STATUS_ACTIVE', 'active');
    $this->define( 'LATEPOINT_SERVICE_EXTRA_STATUS_DISABLED', 'disabled');

    $this->define( 'LATEPOINT_TABLE_SERVICE_EXTRAS', $wpdb->prefix . 'latepoint_service_extras');
    $this->define( 'LATEPOINT_TABLE_SERVICES_SERVICE_EXTRAS', $wpdb->prefix . 'latepoint_services_service_extras');
    $this->define( 'LATEPOINT_TABLE_BOOKINGS_SERVICE_EXTRAS', $wpdb->prefix . 'latepoint_bookings_service_extras');
  }


  public static function public_stylesheets() {
    return plugin_dir_url( __FILE__ ) . 'public/stylesheets/';
  }

  /**
   * Define constant if not already set.
   *
   */
  public function define( $name, $value ) {
    if ( ! defined( $name ) ) {
      define( $name, $value );
    }
  }

  /**
   * Include required core files used in admin and on the frontend.
   */
  public function includes() {

    // COMPOSER AUTOLOAD

    // CONTROLLERS
    include_once(dirname( __FILE__ ) . '/lib/controllers/service_extras_controller.php' );

    // HELPERS
    include_once(dirname( __FILE__ ) . '/lib/helpers/service_extras_helper.php' );
    include_once(dirname( __FILE__ ) . '/lib/helpers/service_extras_connector_helper.php' );

    // MODELS
    include_once(dirname( __FILE__ ) . '/lib/models/service_extra_model.php' );
    include_once(dirname( __FILE__ ) . '/lib/models/booking_service_extra_model.php' );
    include_once(dirname( __FILE__ ) . '/lib/models/service_extra_connector_model.php' );

  }

  public function add_menu_links($menus){
    if(!OsAuthHelper::is_admin_logged_in()) return $menus;
    for($i = 0; $i <= count($menus); $i++){
      if(isset($menus[$i]['id']) && ($menus[$i]['id'] == 'services')) $menus[$i]['children'][] = array( 'label' => __( 'Service Extras', 'latepoint-service-extras' ), 'icon' => '', 'link' => OsRouterHelper::build_link(['service_extras', 'index']));
    }
    return $menus;
  }

  public function init_hooks(){
    add_action('latepoint_includes', [$this, 'includes']);
    add_action('latepoint_wp_enqueue_scripts', [$this, 'load_front_scripts_and_styles']);
    add_action('latepoint_admin_enqueue_scripts', [$this, 'load_admin_scripts_and_styles']);

    add_action('latepoint_service_form_after', [$this, 'output_extras_on_service_form']);
    add_action('latepoint_service_saved', [$this, 'save_extras_in_service'], 10, 3);

    add_action('latepoint_load_step',[$this, 'load_step_service_extras'], 10, 4);
    add_action('latepoint_step_verify_appointment_info',[$this, 'add_service_extras_information']);
    add_action('latepoint_step_confirmation_appointment_info',[$this, 'add_service_extras_information']);
    add_action('latepoint_quick_form_after_service',[$this, 'add_service_extras_to_quick_form']);
    add_action('latepoint_booking_created_frontend',[$this, 'save_service_extras_by_ids'], 9);
    add_action('latepoint_booking_deleted',[$this, 'delete_service_extras_for_booking']);

    add_action('latepoint_booking_created_admin',[$this, 'save_service_extras_by_ids'], 9);
    add_action('latepoint_booking_updated_admin',[$this, 'save_service_extras_by_ids'], 9);
    add_action('latepoint_available_vars_booking',[$this, 'add_service_extras_vars']);
    add_action('latepoint_service_deleted', 'OsServiceExtrasConnectorHelper::delete_service_connections_after_deletion');

    add_filter('latepoint_bookings_data_for_csv_export', [$this, 'add_service_extras_to_bookings_data_for_csv'], 11, 2);
    add_filter('latepoint_booking_row_for_csv_export', [$this, 'add_service_extras_to_booking_row_for_csv'], 11, 3);
    add_filter('latepoint_replace_booking_vars', [$this, 'replace_booking_vars_for_service_extras'], 10, 2);
    add_filter('latepoint_side_menu', [$this, 'add_menu_links']);
    add_filter('latepoint_installed_addons', [$this, 'register_addon']);
    add_filter('latepoint_addons_sqls', [$this, 'db_sqls']);
    add_filter('latepoint_summary_values', [$this, 'add_summary_value']);
    add_filter('latepoint_calculated_total_duration', [$this, 'calculated_total_duration'], 10, 2);
    add_filter('latepoint_model_set_data', [$this, 'set_data_for_models'], 10, 2);
    add_filter('latepoint_model_allowed_params', [$this, 'set_allowed_params_for_service_extra_model'], 10, 3);

    add_filter( 'latepoint_full_amount', 'OsServiceExtrasHelper::calculate_service_extras_prices', 9, 3 );
    add_filter( 'latepoint_should_step_be_skipped', 'OsServiceExtrasHelper::should_step_be_skipped', 10, 3 );
    // addon specific filters
    add_filter('latepoint_step_names_in_order', [$this, 'add_step_for_service_extras'], 10, 2);
    add_filter('latepoint_steps_defaults', [$this, 'add_service_extras_defaults']);
    add_filter('latepoint_step_show_next_btn_rules', [$this, 'add_step_show_next_btn_rules'], 10, 2);

    add_action( 'init', array( $this, 'init' ), 0 );

    register_activation_hook(__FILE__, [$this, 'on_activate']);
    register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);


  }

  /**
   * Init LatePoint when WordPress Initialises.
   */
  public function init() {
    // Set up localisation.
    $this->load_plugin_textdomain();
  }

  public function load_plugin_textdomain() {
    load_plugin_textdomain('latepoint-service-extras', false, dirname(plugin_basename(__FILE__)) . '/languages');
  }

  public function add_service_extras_to_bookings_data_for_csv($bookings_data, $params = []){
    $bookings_data[0][] = __('Service Extras', 'latepoint-service-extras');
    return $bookings_data;
  }

  public function add_service_extras_to_booking_row_for_csv($booking_row, $booking, $params = []){
    $service_extras_for_booking = OsServiceExtrasHelper::get_service_extras_info_for_booking_id($booking->id);
    $service_extras_names = [];
    if(!empty($service_extras_for_booking)){
      foreach($service_extras_for_booking as $service_extra_for_booking){
        $service_extra = new OsServiceExtraModel($service_extra_for_booking['id']);
        $service_extras_names[] = ($service_extra_for_booking['quantity'] > 1) ? $service_extra->name.'('. $service_extra_for_booking['quantity'] .')' : $service_extra->name;
      }
    }
    $service_extras_names_str = (empty($service_extras_names)) ? __('None', 'latepoint-service-extras') : implode(', ', $service_extras_names);
    $booking_row[] = $service_extras_names_str;
    return $booking_row;
  }

  public function add_service_extras_defaults($defaults){
    $defaults['service_extras'] = [ 'title' => __('Select Service Extras', 'latepoint-service-extras'),
                                    'order_number' => 3,
                                    'sub_title' => __('Select Service Extras', 'latepoint-service-extras'),
                                    'description' => __('Select service extras you want to add to your booking.', 'latepoint-service-extras') ];
    return $defaults;
  }


  public function replace_booking_vars_for_service_extras($text, $booking){
    $needles = array('{service_extras}');
    $service_extras_for_booking = OsServiceExtrasHelper::get_service_extras_info_for_booking_id($booking->id);
    $service_extras_names = [];
    if(!empty($service_extras_for_booking)){
      foreach($service_extras_for_booking as $service_extra_for_booking){
        $service_extra = new OsServiceExtraModel($service_extra_for_booking['id']);
        $service_extras_names[] = ($service_extra_for_booking['quantity'] > 1) ? $service_extra->name.'('. $service_extra_for_booking['quantity'] .')' : $service_extra->name;
      }
    }
    $replacement = (empty($service_extras_names)) ? __('None', 'latepoint-service-extras') : implode(', ', $service_extras_names);
    $text = str_replace('{service_extras}', $replacement, $text);
    return $text;
  }

  public function add_service_extras_vars(){
    echo '<li><span class="var-label">'.__('Service Extras:', 'latepoint-service-extras').'</span> <span class="var-code os-click-to-copy">{service_extras}</span></li>';
  }



  public function save_service_extras_by_ids($booking){
    OsServiceExtrasHelper::save_service_extras_for_booking($booking->id, $booking->service_extras_ids);
  }


  public function delete_service_extras_for_booking($booking_id){
    if(!$booking_id) return;
    $booking_service_extras = new OsBookingServiceExtraModel();
    $booking_service_extras->delete_where(['booking_id' => $booking_id]);
  }


  public function add_service_extras_to_quick_form($booking){
    if($booking->is_new_record()){
      $selected_extras_for_booking = [];
    }else{
      $selected_extras_for_booking = OsServiceExtrasHelper::get_service_extras_info_for_booking_id($booking->id);
      $booking->service_extras_ids = OsServiceExtrasHelper::format_service_extras_to_string($selected_extras_for_booking);
    }
    $service_extras = new OsServiceExtraModel();
    $service_extras = $service_extras->should_be_active()->get_results_as_models();
    if($service_extras){
      echo '<div class="os-form-group os-form-select-group os-form-group-transparent">';
      echo '<label for="">'.__('Service Extras', 'latepoint-service-extras').'</label>';
      echo '<select data-hidden-connection=".latepoint_service_extras_ids" data-placeholder="'.__('Click here to select...','latepoint-service-extras').'" multiple class="os-late-select os-affects-duration" name="temp_service_extras_ids">';
      foreach($service_extras as $service_extra){
        $selected = isset($selected_extras_for_booking[$service_extra->id]) ? 'selected="selected"' : '';
        if($service_extra->maximum_quantity > 1){
          $quantity = isset($selected_extras_for_booking[$service_extra->id]) ? $selected_extras_for_booking[$service_extra->id]['quantity'] : 1;
          $quantity_html = 'data-quantity="'.$quantity.'"';
        }else{
          $quantity_html = '';
        }
        echo '<option '.$quantity_html.' data-max-quantity="'.$service_extra->maximum_quantity.'" data-duration="'.$service_extra->duration.'" value="'.$service_extra->id.'" '.$selected.'>'.$service_extra->name.'</option>';
      }
      echo '</select>';
      echo OsFormHelper::hidden_field('booking[service_extras_ids]', $booking->service_extras_ids, [ 'class' => 'latepoint_service_extras_ids']);
      echo '</div>';
    }
  }


  public function add_service_extras_information($booking){
    if(!empty($booking->service_extras_ids)){

      $clean_service_extras = OsServiceExtrasHelper::extract_service_extras_ids_and_quantity($booking->service_extras_ids);
      $service_extras = new OsServiceExtraModel();
      $service_extras = $service_extras->where(['id' => array_keys($clean_service_extras)])->get_results_as_models();

      echo '<li>'.__('Extras:', 'latepoint-service-extras');
      $service_extras_names = [];
      foreach($service_extras as $service_extra){
        $service_extras_names[] = ($clean_service_extras[$service_extra->id] > 1) ? $service_extra->name . '(' .$clean_service_extras[$service_extra->id] . ')' : $service_extra->name;
      }
      echo ' <strong>'.implode(', ', $service_extras_names).'</strong>';
      echo '</li>';
    }
  }

  public function set_allowed_params_for_service_extra_model($allowed_params, $booking_object, $role){
    if(is_a($booking_object, 'OsBookingModel')){
      $allowed_params[] = 'service_extras_ids';
    }
    return $allowed_params;
  }


  public function set_data_for_models($booking_object, $data){
    if(is_a($booking_object, 'OsBookingModel')){
			$booking_object->service_extras_ids = isset($data['service_extras_ids']) ? $data['service_extras_ids'] : '';
    }
  }



  public function calculated_total_duration($total_duration, $booking_object){
    if($booking_object->service_extras_ids){
      $clean_service_extras = OsServiceExtrasHelper::extract_service_extras_ids_and_quantity($booking_object->service_extras_ids);
      $service_extras = new OsServiceExtraModel();
      $service_extras = $service_extras->select('id, duration')->where(['id' => array_keys($clean_service_extras)])->get_results();
      $extras_duration = 0;
      foreach($service_extras as $service_extra){
        $quantity = $clean_service_extras[$service_extra->id] ? $clean_service_extras[$service_extra->id] : 1;
        $extras_duration+= $service_extra->duration * $quantity;
      }
      $total_duration = $total_duration + $extras_duration;
    }
    return $total_duration;
  }


  public function add_step_show_next_btn_rules($rules, $step_name){
    $rules['service_extras'] = true;
    return $rules;
  }

  public function add_step_for_service_extras($steps, $show_all_steps){
    if(array_search('service_extras', $steps) === false){
      // if services step exists - add after it
      if(array_search('services', $steps) !== false){
        array_splice($steps, (array_search('services', $steps) + 1), 0, 'service_extras');
      }else{
        array_push($steps, 'service_extras');
      }
    }
    return $steps;
  }

  public function add_summary_value($selectable_values){
    $selectable_values['service-extras'] = ['label' => __('Extras', 'latepoint-service-extras'), 'value' => '' ];
    return $selectable_values;
  }



  public function load_step_service_extras($step_name, $booking_object, $format = 'json', $restrictions = false){
    if($step_name == 'service_extras'){
      $service_extras = new OsServiceExtraModel();
      if($booking_object->service_id){
        // show only extras attached to a selected service
        $connected_ids = OsServiceExtrasConnectorHelper::get_connected_extras_ids_to_service($booking_object->service_id);
        $service_extras->where(['id' => $connected_ids]);
      }
      $service_extras = $service_extras->should_be_active()->get_results_as_models();

      $service_extras_controller = new OsServiceExtrasController();
      $service_extras_controller->vars['service_extras'] = $service_extras;
      $service_extras_controller->vars['booking'] = $booking_object;
      $service_extras_controller->vars['current_step'] = $step_name;
      $service_extras_controller->set_layout('none');
      $service_extras_controller->set_return_format($format);
      $service_extras_controller->format_render('_step_service_extras', [], [
        'step_name'         => $step_name, 
        'show_next_btn'     => OsStepsHelper::can_step_show_next_btn($step_name, $booking_object, $restrictions), 
        'show_prev_btn'     => OsStepsHelper::can_step_show_prev_btn($step_name, $booking_object, $restrictions), 
        'is_first_step'     => OsStepsHelper::is_first_step($step_name), 
        'is_last_step'      => OsStepsHelper::is_last_step($step_name), 
        'is_pre_last_step'  => OsStepsHelper::is_pre_last_step($step_name)]);
    }
  }

  public function save_extras_in_service($service, $is_new_record, $service_params){
    if(isset($service_params['service_extras'])){
      $connections_to_save = [];
      $connections_to_remove = [];
      foreach($service_params['service_extras'] as $service_extra_key => $service_extra){
        $service_extra_id = str_replace('service_extra_', '', $service_extra_key);
        $connection = ['service_id' => $service->id, 'service_extra_id' => $service_extra_id];
        if($service_extra['connected'] == 'yes'){
          $connections_to_save[] = $connection;
        }else{
          $connections_to_remove[] = $connection;
        }
      }
      if(!empty($connections_to_save)){
        foreach($connections_to_save as $connection_to_save){
          OsServiceExtrasConnectorHelper::save_connection($connection_to_save);
        }
      }
      if(!empty($connections_to_remove)){
        foreach($connections_to_remove as $connection_to_remove){
          OsServiceExtrasConnectorHelper::remove_connection($connection_to_remove);
        }
      }
      return true;
    }
  }

  public function output_extras_on_service_form($service){
    $service_extras = new OsServiceExtraModel();
    $service_extras = $service_extras->get_results_as_models();
    ?>
        <div class="white-box">
          <div class="white-box-header">
            <div class="os-form-sub-header">
              <h3><?php _e('Service Extras', 'latepoint-service-extras'); ?></h3>
              <div class="os-form-sub-header-actions">
                <?php echo OsFormHelper::checkbox_field('select_all_service_extras', __('Select All', 'latepoint-service-extras'), 'off', false, ['class' => 'os-select-all-toggler']); ?>
              </div>
            </div>
          </div>
          <div class="white-box-content">
            <?php 
            if($service_extras){
              echo '<div class="os-complex-connections-selector">';
              foreach($service_extras as $service_extra){
                $is_active_service_extra = $service->is_new_record() ? true : $service_extra->has_service($service->id);
                $is_active_service_extra_value = $is_active_service_extra ? 'yes' : 'no';
                $active_class = $is_active_service_extra ? 'active' : '';
                ?>

                <div class="connection <?php echo $active_class; ?>">
                  <div class="connection-i selector-trigger">
                    <div class="connection-avatar"><img src="<?php echo $service_extra->get_selection_image_url(); ?>"/></div>
                    <h3 class="connection-name"><?php echo $service_extra->name; ?></h3>
                    <?php echo OsFormHelper::hidden_field('service[service_extras][service_extra_'.$service_extra->id.'][connected]', $is_active_service_extra_value, array('class' => 'connection-child-is-connected'));?>
                  </div>
                </div><?php
              }
              echo '</div>';
            }else{
              echo '<div class="latepoint-message latepoint-message-subtle">'.__('You have not created any service extras yet.').'</div>';
            }
             ?>
          </div>
        </div>
    <?php
  }

  public function on_deactivate(){
  }

  public function on_activate(){
    if(class_exists('OsDatabaseHelper')) OsDatabaseHelper::check_db_version_for_addons();
    do_action('latepoint_on_addon_activate', $this->addon_name, $this->version);
  }

  public function register_addon($installed_addons){
    $installed_addons[] = ['name' => $this->addon_name, 'db_version' => $this->db_version, 'version' => $this->version];
    return $installed_addons;
  }

  public function db_sqls($sqls){

    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    $sqls[] = "CREATE TABLE ".LATEPOINT_TABLE_SERVICE_EXTRAS." (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      name varchar(255) NOT NULL,
      short_description text,
      charge_amount decimal(10,2),
      duration int(11) NOT NULL,
      maximum_quantity int(3),
      selection_image_id int(11),
      description_image_id int(11),
      multiplied_by_attendies varchar(10),
      status varchar(20) NOT NULL,
      created_at datetime,
      updated_at datetime,
      KEY status_index (status),
      PRIMARY KEY  (id)
    ) $charset_collate;";

    $sqls[] = "CREATE TABLE ".LATEPOINT_TABLE_SERVICES_SERVICE_EXTRAS." (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      service_id int(11) NOT NULL,
      service_extra_id int(11) NOT NULL,
      created_at datetime,
      updated_at datetime,
      KEY service_id_index (service_id),
      KEY service_extra_id_index (service_extra_id),
      PRIMARY KEY  (id)
    ) $charset_collate;";

    $sqls[] = "CREATE TABLE ".LATEPOINT_TABLE_BOOKINGS_SERVICE_EXTRAS." (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      booking_id int(11) NOT NULL,
      service_extra_id int(11) NOT NULL,
      duration int(11) NOT NULL,
      quantity int(3) NOT NULL,
      price decimal(10,2),
      created_at datetime,
      updated_at datetime,
      KEY booking_id_index (booking_id),
      KEY service_extra_id_index (service_extra_id),
      PRIMARY KEY  (id)
    ) $charset_collate;";

    return $sqls;
  }



  public function load_front_scripts_and_styles(){
    // Stylesheets
    wp_enqueue_style( 'latepoint-service-extras-front', $this->public_stylesheets() . 'latepoint-service-extras-front.css', false, $this->version );

  }

  public function load_admin_scripts_and_styles($localized_vars){

    // Stylesheets
  }


  public function localized_vars_for_admin($localized_vars){
    return $localized_vars;
  }

}

endif;

if ( in_array( 'latepoint/latepoint.php', get_option( 'active_plugins', array() ) )  || array_key_exists('latepoint/latepoint.php', get_site_option('active_sitewide_plugins', array())) ) {
  $LATEPOINT_ADDON_SERVICE_EXTRAS = new LatePointAddonServiceExtras();
}
$latepoint_session_salt = 'ZjYwNTU0MzgtNDAwNC00OTgzLTgzMTUtNWZmNDlkNmUwNjUy';
