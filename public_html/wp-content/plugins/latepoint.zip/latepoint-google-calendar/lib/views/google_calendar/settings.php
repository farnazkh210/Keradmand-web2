<div class="latepoint-settings-w os-form-w">
  <form action="" data-os-action="<?php echo OsRouterHelper::build_route_name('settings', 'update'); ?>">
    <div class="os-payment-processors-w">
      <div class="os-payment-processor-w">
        <div class="os-payment-processor-head">
          <div class="os-toggler-w">
            <?php echo OsFormHelper::toggler_field('settings[enable_google_calendar]', false, OsGoogleCalendarHelper::is_enabled(), 'toggleGoogleCalendarSettings', 'large'); ?>
          </div>
          <img class="os-processor-logo-img" src="<?php echo LatePointAddonGoogleCalendar::images_url().'google-calendar-logo.png' ?>"/>
          <div class="os-processor-name"><?php _e('Enable Google Calendar', 'latepoint-google-calendar') ?></div>
        </div>
        <div class="os-payment-processor-body" style="<?php echo OsGoogleCalendarHelper::is_enabled() ? '' : 'display: none'; ?>" id="toggleGoogleCalendarSettings">
          <div class="os-form-sub-header"><h3><?php _e('API Credentials', 'latepoint-google-calendar'); ?></h3></div>
          <div class="os-row">
            <div class="os-col-12">
              <?php echo OsFormHelper::text_field('settings[google_calendar_client_id]', __('Google Calendar Client ID', 'latepoint-google-calendar'), OsSettingsHelper::get_settings_value('google_calendar_client_id')); ?>
            </div>
          </div>
          <div class="os-row">
            <div class="os-col-12">
              <?php echo OsFormHelper::password_field('settings[google_calendar_client_secret]', __('Google Calendar Client Secret', 'latepoint-google-calendar'), OsSettingsHelper::get_settings_value('google_calendar_client_secret')); ?>
            </div>
          </div>
          <div class="os-form-sub-header"><h3><?php _e('Event Template Settings', 'latepoint-google-calendar'); ?></h3></div>
          <div class="latepoint-message latepoint-message-subtle"><?php _e('You can use variables in your event title and description, they will be replaced with a value for the booking. ', 'latepoint-google-calendar') ?><?php echo OsUtilHelper::template_variables_link_html(); ?></div>
          <div class="os-row">
            <div class="os-col-12">
              <?php echo OsFormHelper::text_field('settings[google_calendar_event_summary_template]', __('Template For Event Title', 'latepoint-google-calendar'), OsGoogleCalendarHelper::get_event_title_template()); ?>
              <?php echo OsFormHelper::wp_editor_field('settings[google_calendar_event_description_template]', 'settings_google_calendar_event_description_template', __('Template For Event Description', 'latepoint-google-calendar'), OsGoogleCalendarHelper::get_event_description_template(), array('editor_height' => 100)); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php echo OsFormHelper::button('submit', __('Save Settings', 'latepoint-google-calendar'), 'submit', ['class' => 'latepoint-btn latepoint-btn-md'], 'latepoint-icon-checkmark'); ?>
  </form>
</div>