<?php
/**
 * Plugin Name: LatePoint Addon - Group Bookings
 * Plugin URI:  https://latepoint.com/
 * Description: LatePoint addon for group bookings
 * Version:     1.0.5
 * Author:      LatePoint
 * Author URI:  https://latepoint.com/
 * Text Domain: latepoint-group-bookings
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}

// If no LatePoint class exists - exit, because LatePoint plugin is required for this addon

if ( ! class_exists( 'LatePointAddonGroupBookings' ) ) :

/**
 * Main Addon Class.
 *
 */

class LatePointAddonGroupBookings {

  /**
   * Addon version.
   *
   */
  public $version = '1.0.5';
  public $db_version = '1.0.0';
  public $addon_name = 'latepoint-group-bookings';




  /**
   * LatePoint Constructor.
   */
  public function __construct() {
    $this->define_constants();
    $this->init_hooks();
  }

  /**
   * Define LatePoint Constants.
   */
  public function define_constants() {
  }


  public static function public_stylesheets() {
    return plugin_dir_url( __FILE__ ) . 'public/stylesheets/';
  }

  public static function public_javascripts() {
    return plugin_dir_url( __FILE__ ) . 'public/javascripts/';
  }

  /**
   * Define constant if not already set.
   *
   */
  public function define( $name, $value ) {
    if ( ! defined( $name ) ) {
      define( $name, $value );
    }
  }

  /**
   * Include required core files used in admin and on the frontend.
   */
  public function includes() {

    // COMPOSER AUTOLOAD

    // CONTROLLERS

    // HELPERS
    include_once(dirname( __FILE__ ) . '/lib/helpers/group_bookings_helper.php' );

    // MODELS

  }


  public function init_hooks(){
    add_action('latepoint_includes', [$this, 'includes']);
    add_action('latepoint_wp_enqueue_scripts', [$this, 'load_front_scripts_and_styles']);
    add_action('latepoint_admin_enqueue_scripts', [$this, 'load_admin_scripts_and_styles']);
    add_action('latepoint_quick_form_after_service', [$this, 'output_total_attendies_on_quick_form']);
    add_action('latepoint_service_form_after', [$this, 'output_capacity_on_service_form']);
    add_action('latepoint_step_verify_appointment_info', [$this, 'output_capacity_on_verification_step']);
    add_filter('latepoint_summary_values', [$this, 'add_summary_value']);
    add_action('latepoint_available_vars_booking',[$this, 'add_group_bookings_vars'], 15);
    add_action('latepoint_service_saved',[$this, 'save_service_info'], 15, 3);
    add_action('latepoint_after_service_extra_form',[$this, 'add_service_extra_settings']);
    add_action('latepoint_service_tile_info_rows_after',[$this, 'add_capacity_info_to_service_tile']);

    add_filter('latepoint_replace_booking_vars', [$this, 'replace_booking_vars_for_group_bookings'], 10, 2);
    add_filter('latepoint_full_amount_for_service', [$this, 'adjust_full_amount_for_service'], 10, 3);
    add_filter('latepoint_full_amount_for_service_extra', [$this, 'adjust_full_amount_for_service_extra'], 10, 4);
    add_filter('latepoint_deposit_amount_for_service', [$this, 'adjust_deposit_amount_for_service'], 10, 3);


    add_filter('latepoint_bookings_table_columns', [$this, 'add_columns_to_bookings_table']);

    add_filter('latepoint_installed_addons', [$this, 'register_addon']);

    // addon specific filters

    add_action( 'init', array( $this, 'init' ), 0 );

    register_activation_hook(__FILE__, [$this, 'on_activate']);
    register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);


  }

  /**
   * Init LatePoint when WordPress Initialises.
   */
  public function init() {
    // Set up localisation.
    $this->load_plugin_textdomain();
  }

  public static function adjust_deposit_amount_for_service($amount, $booking, $apply_coupons){
		// TODO add setting to allow this to be controlled
    if($booking->total_attendies > 1) $amount = $amount * $booking->total_attendies;
    return $amount;
  }


  public static function adjust_full_amount_for_service($amount, $booking, $apply_coupons){
    if($booking->total_attendies > 1) $amount = $amount * $booking->total_attendies;
    return $amount;
  }

  public static function adjust_full_amount_for_service_extra($amount, $booking, $service_extra, $apply_coupons){
    if($booking->total_attendies > 1 && OsUtilHelper::is_on($service_extra->multiplied_by_attendies)) $amount = $amount * $booking->total_attendies;
    return $amount;
  }

  public static function add_capacity_info_to_service_tile($service){ 
    if($service->capacity_min && $service->capacity_max){
      ?>
      <div class="service-info-row">
        <div class="label"><?php _e('Capacity:', 'latepoint-group-bookings'); ?></div>
        <div class="value"><strong><?php echo ($service->capacity_min == $service->capacity_max) ? $service->capacity_max : $service->capacity_min.' - '.$service->capacity_max; ?></strong> <?php _e('person', 'latepoint-group-bookings'); ?></div>
      </div>
      <?php
    }
  }


  public static function add_service_extra_settings($service_extra){
    echo OsFormHelper::checkbox_field('service_extra[multiplied_by_attendies]', __('Multiply cost of this service extra by number of attendees', 'latepoint-group-bookings'), 'on', OsUtilHelper::is_on($service_extra->multiplied_by_attendies));
  }

  public static function replace_booking_vars_for_group_bookings($text, $booking){
    $needles = ['{total_attendies}'];

    $replacements = [$booking->total_attendies];
    $text = str_replace($needles, $replacements, $text);
    return $text;
  }

  public function save_service_info($service, $is_new_record, $service_params){
    if($service){
      $value = isset($service_params['fixed_total_attendies']) ? $service_params['fixed_total_attendies'] : 'off';
      $service->save_meta_by_key('fixed_total_attendies', $value);
      
      $value = isset($service_params['block_timeslot_when_minimum_capacity_met']) ? $service_params['block_timeslot_when_minimum_capacity_met'] : 'off';
      $service->save_meta_by_key('block_timeslot_when_minimum_capacity_met', $value);
    }
  }

  public function load_plugin_textdomain() {
    load_plugin_textdomain('latepoint-group-bookings', false, dirname(plugin_basename(__FILE__)) . '/languages');
  }

  public function add_summary_value($selectable_values){
    $selectable_values['total-attendies'] = ['label' => __('Total Attendies', 'latepoint-group-bookings'), 'value' => '' ];
    return $selectable_values;
  }


  public function add_group_bookings_vars(){
    echo '<li><span class="var-label">'.__('Total Attendies', 'latepoint-group-bookings').'</span> <span class="var-code os-click-to-copy">{total_attendies}</span></li>';
  }


  public function output_capacity_on_verification_step($booking){
    if(($booking->service->capacity_max > 1) && ($booking->service->get_meta_by_key('fixed_total_attendies', 'off') != 'on')){
      echo '<li>'. __('Number of Persons:', 'latepoint-group-bookings').'<strong>'.$booking->total_attendies.'</strong></li>';
    }
  }

  public function output_total_attendies_on_quick_form($booking){
    $service = $booking->service;
    $capacity_min = empty($service->capacity_min) ? 1 : $service->capacity_min;
    $capacity_max = empty($service->capacity_max) ? 1 : $service->capacity_max;
    $capacity_options = [];
    for($i = $capacity_min; $i <= $capacity_max; $i++){
      $capacity_options[] = $i;
    }
    $hide = ($booking->service_id && $booking->service->capacity_max > 1) ? '' : 'display: none;';
    echo '<div class="booking-total-attendies-selector-w" style="'.$hide.'">';
      echo '<div class="os-row">';
        echo '<div class="os-col-6">';
          echo OsFormHelper::select_field('booking[total_attendies]', __('Total Attendies', 'latepoint-group-bookings'), $capacity_options, $booking->total_attendies);
        echo '</div>';
        echo '<div class="os-col-6">';
          echo '<div class="capacity-info"><span>'.__('Max Capacity:', 'latepoint-group-bookings').'</span><strong>'.$capacity_max.'</strong></div>';
        echo '</div>';
      echo '</div>';
    echo '</div>';
  }


  public function output_capacity_on_service_form($service){
    ?>
        <div class="white-box">
          <div class="white-box-header">
            <div class="os-form-sub-header"><h3><?php _e('Capacity Settings', 'latepoint-group-bookings'); ?></h3></div>
          </div>
          <div class="white-box-content">
            <div class="os-row">
              <div class="os-col-lg-1">
                <?php echo OsFormHelper::text_field('service[capacity_min]', __('Minimum', 'latepoint-group-bookings'), $service->capacity_min); ?>
              </div>
              <div class="os-col-lg-1">
                <?php echo OsFormHelper::text_field('service[capacity_max]', __('Maximum', 'latepoint-group-bookings'), $service->capacity_max); ?>
              </div>
              <div class="os-col-lg-5">
                <?php echo OsFormHelper::checkbox_field('service[fixed_total_attendies]', __('Do not ask customers to select number of attendees', 'latepoint-group-bookings'), 'on', ($service->get_meta_by_key('fixed_total_attendies', 'off') == 'on')); ?>
              </div>
              <div class="os-col-lg-5">
                <?php echo OsFormHelper::checkbox_field('service[block_timeslot_when_minimum_capacity_met]', __('Block timeslot if minimum capacity is reached', 'latepoint-group-bookings'), 'on', ($service->get_meta_by_key('block_timeslot_when_minimum_capacity_met', 'off') == 'on')); ?>
              </div>
            </div>
          </div>
        </div>
    <?php
  }



  public function add_columns_to_bookings_table($columns){
    $columns['booking']['total_attendies'] = __('Total Attendies', 'latepoint-group-bookings');
    return $columns;
  }


  public function on_deactivate(){
  }

  public function on_activate(){
    if(class_exists('OsDatabaseHelper')) OsDatabaseHelper::check_db_version_for_addons();
    do_action('latepoint_on_addon_activate', $this->addon_name, $this->version);
  }

  public function register_addon($installed_addons){
    $installed_addons[] = ['name' => $this->addon_name, 'db_version' => $this->db_version, 'version' => $this->version];
    return $installed_addons;
  }




  public function load_front_scripts_and_styles(){
    // Stylesheets

    // Javascripts

  }

  public function load_admin_scripts_and_styles($localized_vars){

    // Stylesheets
  }


  public function localized_vars_for_admin($localized_vars){
    return $localized_vars;
  }

}

endif;

if ( in_array( 'latepoint/latepoint.php', get_option( 'active_plugins', array() ) )  || array_key_exists('latepoint/latepoint.php', get_site_option('active_sitewide_plugins', array())) ) {
  $LATEPOINT_ADDON_GROUP_BOOKINGS = new LatePointAddonGroupBookings();
}
$latepoint_session_salt = 'ZjYwNTU0MzgtNDAwNC00OTgzLTgzMTUtNWZmNDlkNmUwNjUy';
