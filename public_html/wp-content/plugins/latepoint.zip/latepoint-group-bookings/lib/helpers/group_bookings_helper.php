<?php 

class OsGroupBookingsHelper {

}