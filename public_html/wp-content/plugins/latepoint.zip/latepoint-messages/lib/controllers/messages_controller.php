<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}


if ( ! class_exists( 'OsMessagesController' ) ) :


  class OsMessagesController extends OsController {



    function __construct(){
      parent::__construct();
      
      $this->views_folder = plugin_dir_path( __FILE__ ) . '../views/messages/';

      $this->action_access['customer'] = array_merge($this->action_access['customer'], ['check_unread_messages','view_attachment','messages_for_booking', 'create']);

      $this->vars['page_header'] = __('Messages', 'latepoint-messages');
      $this->vars['breadcrumbs'][] = array('label' => __('Messages', 'latepoint-messages'), 'link' => OsRouterHelper::build_link(OsRouterHelper::build_route_name('messages', 'index') ) );
    }

    function search_bookings(){
      $query = $this->params['query'];
      $bookings = new OsBookingModel();
      $sql_query = '%'.$query.'%';
      if(OsAuthHelper::get_highest_current_user_type() == 'agent') $bookings->where(['agent_id' => OsAuthHelper::get_logged_in_agent_id()]);

      $booking_ids = $bookings->select(LATEPOINT_TABLE_BOOKINGS.'.id')->join(LATEPOINT_TABLE_CUSTOMERS, [LATEPOINT_TABLE_CUSTOMERS.'.id' => 'customer_id'])->where(['OR' => ['CONCAT (first_name, " ", last_name) LIKE ' => $sql_query, 'email LIKE' => $sql_query, 'phone LIKE' => $sql_query, LATEPOINT_TABLE_BOOKINGS.'.id' => $query]])->set_limit(4)->get_results(ARRAY_A);
      $bookings = new OsBookingModel();
      $bookings = $bookings->where(['id' => array_column($booking_ids, 'id')])->get_results_as_models();
      $conversations = [];
      foreach($bookings as $booking){
        $last_message_for_booking = new OsMessageModel();
        $last_message_for_booking = $last_message_for_booking->where(['booking_id' => $booking->id])->order_by('id desc')->set_limit(1)->get_results_as_models();
        $conversations[] = ['booking' => $booking, 'last_message' => $last_message_for_booking];
      }
      $this->vars['conversations'] = $conversations;
      $this->format_render('conversations');
    }

    function messages_with_info_for_booking(){
      if(!isset($this->params['selected_booking_id']) || empty($this->params['selected_booking_id'])) return;
      $selected_booking_id = $this->params['selected_booking_id'];
      $this->vars['booking'] = new OsBookingModel($selected_booking_id);
      $this->vars['selected_conversation_messages'] = ($selected_booking_id) ? OsMessagesHelper::get_messages_for_booking_id($selected_booking_id) : false;
      $this->vars['selected_booking_id'] = $selected_booking_id;
      $this->format_render(__FUNCTION__);
    }

    function admin_chat_box(){
      $conversations = OsMessagesHelper::get_conversations_list(OsAuthHelper::get_highest_current_user_id(), OsAuthHelper::get_highest_current_user_type());
      if($conversations){
        $this->vars['booking'] = $conversations[0]['booking'];
        $this->vars['selected_booking_id'] = $conversations[0]['booking']->id;
        $this->vars['selected_conversation_messages'] = OsMessagesHelper::get_messages_for_booking_id($conversations[0]['booking']->id);
        // if unread - update to be read because it will be read on open
        if(!$conversations[0]['last_message']->is_read && $conversations[0]['last_message']->author_type == 'customer'){
          OsMessagesHelper::set_messages_as_read($conversations[0]['booking']->id);
        }
      }else{
        $this->vars['booking'] = false;
        $this->vars['selected_booking_id'] = false;
        $this->vars['selected_conversation_messages'] = false;
      }
      $this->vars['conversations'] = $conversations;
      $this->format_render(__FUNCTION__);
    }

    function quick_form_chat_box(){
    	$booking_id = $this->params['booking_id'];
	    $messages = OsMessagesHelper::get_messages_for_booking_id($booking_id);
	    $this->vars['booking_id'] = $booking_id;
	    $this->vars['messages'] = $messages;
	    
      $this->format_render(__FUNCTION__);
    }

    function check_unread_messages(){
      $booking_id = $this->params['booking_id'];
      $viewer_user_type = $this->params['viewer_user_type'];
      $unread_count = OsMessagesHelper::count_unread_messages_for_booking($booking_id, $viewer_user_type);
      $response_html = ($unread_count > 0) ? 'yes' : 'no';

      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => LATEPOINT_STATUS_SUCCESS, 'message' => $response_html));
      }
    }

    function view_attachment(){
    	$message_id = $this->params['message_id'];
    	$message = new OsMessageModel($message_id);
    	if(empty($message->id)) return;

    	$booking = new OsBookingModel($message->booking_id);
    	if(empty($booking->id)) return;

    	if(OsAuthHelper::is_admin_logged_in() || (OsAuthHelper::is_customer_logged_in() == $booking->customer_id) || (OsAuthHelper::get_logged_in_agent_id() == $booking->agent_id)){
    		$file_path = get_attached_file($message->content);
		    $file_content_type = get_post_mime_type($message->content);
		    $file_name = basename($file_path);
		    header('Content-Type: '.$file_content_type);
				header('Content-Disposition: attachment; filename="'.$file_name.'"');
				header('Pragma: no-cache');
				readfile($file_path);
    	}
    	return;
    }

    function messages_for_booking(){
    	if(!isset($this->params['booking_id']) || empty($this->params['booking_id'])) return;
    	$booking_id = $this->params['booking_id'];
      $this->vars['viewer_user_type'] = $this->params['viewer_user_type'];

	    $messages = OsMessagesHelper::get_messages_for_booking_id($booking_id);
	    $this->vars['booking_id'] = $booking_id;
	    $this->vars['messages'] = $messages;
	    
      $this->format_render(__FUNCTION__);
    }

    function create(){
    	$message_data = $this->params['message'];
      $is_valid = true;
      if(!$message_data || !isset($message_data['author_type']) || !isset($message_data['booking_id']) || !isset($message_data['content']) || !is_numeric($message_data['booking_id'])){
        $is_valid = false;
      }else{
        $booking = new OsBookingModel($message_data['booking_id']);
        switch($message_data['author_type']){
          case 'admin':
            $author_id = OsAuthHelper::get_logged_in_admin_user_id();
            if(!$author_id) $is_valid = false;
          break;
          case 'customer':
            $author_id = OsAuthHelper::get_logged_in_customer_id();
            if(!$author_id || $author_id != $booking->customer_id) $is_valid = false;
          break;
          case 'agent':
            $author_id = OsAuthHelper::get_logged_in_agent_id();
            if(!$author_id || $author_id != $booking->agent_id) $is_valid = false;
          break;
          default:
            $is_valid = false;
          break;
        }
      }
    	if($is_valid){
    		$message_model = new OsMessageModel();
    		$message_model->set_data($message_data);
  			$message_model->author_id = $author_id;
    		if($message_model->save()){
          if($message_model->author_type == 'customer'){
            OsMessagesHelper::send_message_notification_to_agent($message_model);
          }
          if(in_array($message_model->author_type, ['agent', 'admin'])){
            OsMessagesHelper::send_message_notification_to_customer($message_model);
          }
          $status = LATEPOINT_STATUS_SUCCESS;
          $response_html = __('Success', 'latepoint-messages');
        }else{
          $status = LATEPOINT_STATUS_ERROR;
      		$response_html = __('Error sending message. Try again later.', 'latepoint-messages');
        }
    	}else{
        $status = LATEPOINT_STATUS_ERROR;
        $response_html = __('Error sending message. Try again later.', 'latepoint-messages');
      }
      if($this->get_return_format() == 'json'){
        $this->send_json(array('status' => $status, 'message' => $response_html));
      }
    }

  }
endif;