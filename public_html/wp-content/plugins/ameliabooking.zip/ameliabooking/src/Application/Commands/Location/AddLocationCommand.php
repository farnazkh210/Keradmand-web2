<?php

namespace AmeliaBooking\Application\Commands\Location;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class AddLocationCommand
 *
 * @package AmeliaBooking\Application\Commands\Location
 */
class AddLocationCommand extends Command
{

}
