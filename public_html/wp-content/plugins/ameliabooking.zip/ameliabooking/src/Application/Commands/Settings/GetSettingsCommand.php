<?php

namespace AmeliaBooking\Application\Commands\Settings;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetSettingsCommand
 *
 * @package AmeliaBooking\Application\Commands\Settings
 */
class GetSettingsCommand extends Command
{

}
