<?php
/**
 * @copyright © TMS-Plugins. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Activation;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class ParseDomainCommand
 *
 * @package AmeliaBooking\Application\Commands\Activation
 */
class ParseDomainCommand extends Command
{

}
