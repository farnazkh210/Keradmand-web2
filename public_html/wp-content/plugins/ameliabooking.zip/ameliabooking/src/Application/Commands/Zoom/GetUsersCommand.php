<?php

namespace AmeliaBooking\Application\Commands\Zoom;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetUsersCommand
 *
 * @package AmeliaBooking\Application\Commands\Zoom
 */
class GetUsersCommand extends Command
{
    /**
     * GetUsersCommand constructor.
     *
     * @param $args
     */
    public function __construct($args)
    {
        parent::__construct($args);
    }
}
