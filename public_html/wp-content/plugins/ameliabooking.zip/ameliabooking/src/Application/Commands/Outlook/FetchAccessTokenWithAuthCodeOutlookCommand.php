<?php

namespace AmeliaBooking\Application\Commands\Outlook;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class FetchAccessTokenWithAuthCodeOutlookCommand
 *
 * @package AmeliaBooking\Application\Commands\Outlook
 */
class FetchAccessTokenWithAuthCodeOutlookCommand extends Command
{

}
