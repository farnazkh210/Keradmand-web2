<?php

namespace AmeliaBooking\Application\Commands\Bookable\Category;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetCategoriesCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Category
 */
class GetCategoriesCommand extends Command
{

}
