<?php

namespace AmeliaBooking\Application\Commands\PaymentGateway;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class MolliePaymentCommand
 *
 * @package AmeliaBooking\Application\Commands\PaymentGateway
 */
class MolliePaymentCommand extends Command
{

}
