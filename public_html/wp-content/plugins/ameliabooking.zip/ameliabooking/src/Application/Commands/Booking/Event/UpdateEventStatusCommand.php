<?php

namespace AmeliaBooking\Application\Commands\Booking\Event;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateEventStatusCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Event
 */
class UpdateEventStatusCommand extends Command
{

}
