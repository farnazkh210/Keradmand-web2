<?php

namespace AmeliaBooking\Application\Commands\Bookable\Service;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateServicesPositionsCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Service
 */
class UpdateServicesPositionsCommand extends Command
{

}
